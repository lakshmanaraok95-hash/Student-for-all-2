import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { api } from './api.js';

// One scanner for the whole class: this device scans each student's personal QR
// (shown on the student's phone under "My QR").
export default function KioskScanner({ sessionId, teacherId }) {
  const [facing, setFacing] = useState('environment'); // 'environment' = back camera
  const [last, setLast] = useState(null);              // { ok, text }
  const [recent, setRecent] = useState([]);
  const [camError, setCamError] = useState('');
  const seen = useRef(new Map()); // token -> time, so one QR isn't processed repeatedly
  const busy = useRef(false);

  useEffect(() => {
    const user = { id: teacherId, role: 'teacher' };
    const scanner = new Html5Qrcode('kiosk-reader');
    setCamError('');

    scanner
      .start(
        { facingMode: facing },
        { fps: 10, qrbox: { width: 260, height: 260 } },
        async (text) => {
          const now = Date.now();
          if (busy.current || now - (seen.current.get(text) || 0) < 4000) return;
          seen.current.set(text, now);
          busy.current = true;
          try {
            const r = await api(`/api/sessions/${sessionId}/scan-student`,
              { method: 'POST', user, body: { token: text } });
            setLast({ ok: true, text: r.already ? `${r.name} was already present` : `✅ ${r.name} marked present` });
            if (!r.already) setRecent((p) => [r.name, ...p].slice(0, 8));
            if (navigator.vibrate) navigator.vibrate(60);
          } catch (e) {
            setLast({ ok: false, text: e.message });
          } finally {
            setTimeout(() => { busy.current = false; }, 700);
          }
        },
        () => {} // per-frame "no QR found" noise
      )
      .catch(() => setCamError('Camera unavailable. Check browser permissions (HTTPS is required).'));

    return () => {
      if (scanner.isScanning) scanner.stop().catch(() => {});
    };
  }, [sessionId, teacherId, facing]);

  return (
    <div className="mx-auto max-w-sm p-4">
      <h2 className="mb-1 text-center text-lg font-semibold">Scan students</h2>
      <p className="mb-3 text-center text-sm text-gray-500">
        Each student opens <b>My QR</b> on their phone and holds it up to this camera.
      </p>
      <div id="kiosk-reader" className="overflow-hidden rounded-xl" />
      {camError && <p className="mt-2 text-center text-sm text-red-600">{camError}</p>}
      <div className="mt-2 text-center">
        <button className="rounded border px-3 py-1 text-sm"
                onClick={() => setFacing((f) => (f === 'environment' ? 'user' : 'environment'))}>
          Switch camera
        </button>
      </div>
      {last && (
        <p className={`mt-3 rounded p-3 text-center text-lg font-medium ${last.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
          {last.text}
        </p>
      )}
      {recent.length > 0 && (
        <div className="mt-3">
          <p className="text-sm text-gray-500">Marked present just now ({recent.length}):</p>
          <p className="text-sm">{recent.join(' · ')}</p>
        </div>
      )}
    </div>
  );
}

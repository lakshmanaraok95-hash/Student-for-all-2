import { useEffect, useState } from 'react';
import { api } from './api.js';
import TimeField from './TimeField.jsx';

const time = (iso) => new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const day = (iso) => new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
// "HH:MM" in the device's own time (24-hour), the format TimeField uses
const hhmm = (d) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
// today's date at the given "HH:MM"
const atToday = (v) => {
  const [h, m] = v.split(':').map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d;
};
const HHMM = /^\d{1,2}:\d{2}$/;

function timeError(from, to) {
  if (!HHMM.test(from || '') || !HHMM.test(to || '')) return 'Enter the from and to times';
  const s = atToday(from);
  const e = atToday(to);
  if (e <= s) return 'The end time must be after the start time';
  if (e <= new Date()) return 'The end time has already passed';
  if (e - s > 8 * 3600e3) return 'A class can be at most 8 hours long';
  return null;
}

// Teacher: start a class with their own from/to times, pick a class, edit its time, end it.
export default function ClassSessions({ user, session, onSelect, onStarted }) {
  const [courses, setCourses] = useState([]);
  const [list, setList] = useState([]);
  const [slots, setSlots] = useState([]); // this teacher's timetable
  const [form, setForm] = useState({ course_id: '', from: hhmm(new Date()), to: '', loc: null });
  const [editing, setEditing] = useState(null); // { id, from, to }
  const [msg, setMsg] = useState(null);

  const load = () => api('/api/sessions', { user }).then(setList)
    .catch((e) => setMsg({ ok: false, text: e.message }));

  useEffect(() => {
    load();
    api('/api/timetable', { user }).then(setSlots).catch(() => {});
    api('/api/courses', { user }).then((c) => {
      setCourses(c);
      setForm((f) => ({ ...f, course_id: f.course_id || (c[0] ? String(c[0].id) : '') }));
    }).catch(() => {});
  }, [user.id]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  function useMyLocation() {
    if (!navigator.geolocation) return setMsg({ ok: false, text: 'Location is not supported here' });
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setForm((f) => ({ ...f, loc: { lat: p.coords.latitude, lng: p.coords.longitude } }));
        setMsg({ ok: true, text: 'Classroom location saved for this class.' });
      },
      () => setMsg({ ok: false, text: 'Location blocked. Allow it in the browser (HTTPS is required).' }),
      { enableHighAccuracy: true, timeout: 10000 });
  }

  async function start() {
    const err = timeError(form.from, form.to);
    if (err) return setMsg({ ok: false, text: err });
    try {
      const body = {
        course_id: Number(form.course_id),
        starts_at: atToday(form.from).toISOString(),
        ends_at: atToday(form.to).toISOString(),
      };
      if (form.loc) { body.lat = form.loc.lat; body.lng = form.loc.lng; }
      const r = await api('/api/sessions', { method: 'POST', user, body });
      const rows = await api('/api/sessions', { user });
      setList(rows);
      setMsg(null);
      setForm((f) => ({ ...f, from: hhmm(new Date()), to: '' }));
      const s = rows.find((x) => x.id === r.id);
      if (s) onStarted(s); // opens the QR screen
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  async function saveTime() {
    const err = timeError(editing.from, editing.to);
    if (err) return setMsg({ ok: false, text: err });
    try {
      await api(`/api/sessions/${editing.id}/time`, {
        method: 'PUT', user,
        body: { starts_at: atToday(editing.from).toISOString(), ends_at: atToday(editing.to).toISOString() },
      });
      setMsg({ ok: true, text: 'Class time updated.' });
      setEditing(null);
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  async function end(s) {
    try {
      await api(`/api/sessions/${s.id}/end`, { method: 'POST', user });
      setMsg({ ok: true, text: `${s.code} ended. Its QR code no longer works.` });
      if (session && session.id === s.id) onSelect({ ...s, is_open: false });
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  // today's periods from the timetable (1 = Monday ... 7 = Sunday)
  const dow = ((new Date().getDay() + 6) % 7) + 1;
  const todays = slots.filter((s) => s.day === dow);

  const status = (s) => (!s.is_open ? 'Ended' : s.upcoming ? `Starts ${time(s.starts_at)}` : 'Open');

  return (
    <div className="p-4">
      <div className="mb-4 rounded-lg border p-4">
        <h3 className="mb-2 font-semibold">Start a class</h3>
        {todays.length > 0 && (
          <div className="mb-3">
            <p className="mb-1 text-xs text-gray-500">Today's timetable. Tap one to fill in the course and times:</p>
            <div className="flex flex-wrap gap-2">
              {todays.map((s) => (
                <button key={s.id} className="rounded-full border px-3 py-1 text-sm"
                        onClick={() => setForm((f) => ({ ...f, course_id: String(s.course_id), from: s.start_time, to: s.end_time }))}>
                  {s.code} {s.start_time}–{s.end_time}
                </button>
              ))}
            </div>
          </div>
        )}
        <select className="mb-2 w-full rounded border p-2" value={form.course_id} onChange={set('course_id')}>
          {courses.map((c) => <option key={c.id} value={c.id}>{c.code} · {c.title}</option>)}
        </select>
        <div className="mb-2 flex flex-wrap gap-4">
          <div>
            <p className="mb-1 text-xs text-gray-500">From</p>
            <TimeField label="From" value={form.from} onChange={(v) => setForm((f) => ({ ...f, from: v }))} />
          </div>
          <div>
            <p className="mb-1 text-xs text-gray-500">To</p>
            <TimeField label="To" value={form.to} onChange={(v) => setForm((f) => ({ ...f, to: v }))} />
          </div>
        </div>
        <button className="mb-1 rounded border px-3 py-2 text-sm" onClick={useMyLocation}>
          {form.loc ? 'Classroom location saved ✓' : 'Use my location as the classroom'}
        </button>
        <p className="mb-2 text-xs text-gray-500">
          Students can only check in near this spot, and only between the from and to times. If you
          skip the location, the room used for this course last time is reused.
        </p>
        <button className="rounded bg-green-600 px-4 py-2 text-white" onClick={start}>Start class</button>
        {msg && <p className={`mt-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
      </div>

      <h2 className="mb-2 text-lg font-semibold">Your classes</h2>
      {list.length === 0 ? (
        <p className="text-gray-500">No classes yet. Start one above.</p>
      ) : (
        <ul className="divide-y rounded-lg border">
          {list.map((s) => (
            <li key={s.id} className="px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="font-medium">
                    {s.code}
                    {session && session.id === s.id && (
                      <span className="ml-2 rounded-full bg-green-100 px-2 py-0.5 text-xs text-green-800">Selected</span>
                    )}
                  </p>
                  <p className="text-sm text-gray-500">
                    {day(s.starts_at)} {time(s.starts_at)}–{time(s.ends_at)} · {status(s)} · {s.present}/{s.enrolled} present
                  </p>
                </div>
                <div className="flex flex-wrap justify-end gap-2">
                  {!(session && session.id === s.id) && (
                    <button className="rounded border px-3 py-1 text-sm" onClick={() => onSelect(s)}>Select</button>
                  )}
                  {s.is_open && (
                    <>
                      <button className="rounded border px-3 py-1 text-sm"
                              onClick={() => setEditing({ id: s.id, from: hhmm(new Date(s.starts_at)), to: hhmm(new Date(s.ends_at)) })}>
                        Edit time
                      </button>
                      <button className="rounded border px-3 py-1 text-sm text-red-600" onClick={() => end(s)}>End class</button>
                    </>
                  )}
                </div>
              </div>
              {editing && editing.id === s.id && (
                <div className="mt-2 flex flex-wrap items-end gap-3">
                  <div>
                    <p className="mb-1 text-xs text-gray-500">From</p>
                    <TimeField label="From" value={editing.from} onChange={(v) => setEditing((e) => ({ ...e, from: v }))} />
                  </div>
                  <div>
                    <p className="mb-1 text-xs text-gray-500">To</p>
                    <TimeField label="To" value={editing.to} onChange={(v) => setEditing((e) => ({ ...e, to: v }))} />
                  </div>
                  <button className="rounded bg-green-600 px-3 py-2 text-sm text-white" onClick={saveTime}>Save</button>
                  <button className="rounded border px-3 py-2 text-sm" onClick={() => setEditing(null)}>Cancel</button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

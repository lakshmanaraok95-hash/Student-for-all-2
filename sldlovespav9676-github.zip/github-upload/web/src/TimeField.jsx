import { useEffect, useState } from 'react';

// A time picker made of three plain selects (hour : minute AM/PM). It avoids the
// browser's own clock icon and grey box, so it looks the same on every device.
// value / onChange use 24-hour "HH:MM" (or '' while nothing is chosen).

const HOURS = Array.from({ length: 12 }, (_, i) => String(i + 1));
const MINUTES = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0'));

function parse(v) {
  if (!/^\d{1,2}:\d{2}$/.test(v || '')) return { h: '', m: '', p: 'AM' };
  const [H, M] = v.split(':').map(Number);
  return { h: String(H % 12 === 0 ? 12 : H % 12), m: String(M).padStart(2, '0'), p: H >= 12 ? 'PM' : 'AM' };
}

const selectClass =
  'rounded-lg border border-gray-300 bg-white px-2 py-2 text-base text-gray-900 focus:border-green-600 focus:outline-none';

export default function TimeField({ value, onChange, label }) {
  const [t, setT] = useState(() => parse(value));
  useEffect(() => { setT(parse(value)); }, [value]);

  function update(patch) {
    const n = { ...t, ...patch };
    setT(n);
    if (n.h !== '' && n.m !== '') {
      let H = Number(n.h) % 12;
      if (n.p === 'PM') H += 12;
      onChange(`${String(H).padStart(2, '0')}:${n.m}`);
    } else {
      onChange('');
    }
  }

  return (
    <div className="inline-flex items-center gap-1" role="group" aria-label={label}>
      <select className={selectClass} aria-label="hour" value={t.h} onChange={(e) => update({ h: e.target.value })}>
        <option value="">--</option>
        {HOURS.map((h) => <option key={h} value={h}>{h}</option>)}
      </select>
      <span className="text-gray-500">:</span>
      <select className={selectClass} aria-label="minute" value={t.m} onChange={(e) => update({ m: e.target.value })}>
        <option value="">--</option>
        {MINUTES.map((m) => <option key={m} value={m}>{m}</option>)}
      </select>
      <select className={selectClass} aria-label="AM or PM" value={t.p} onChange={(e) => update({ p: e.target.value })}>
        <option>AM</option>
        <option>PM</option>
      </select>
    </div>
  );
}

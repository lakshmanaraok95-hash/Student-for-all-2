import { useEffect, useState } from 'react';
import { api } from './api.js';
import TimeField from './TimeField.jsx';

export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const HHMM = /^\d{1,2}:\d{2}$/;
const toMin = (v) => { const [h, m] = v.split(':').map(Number); return h * 60 + m; };

function timeError(from, to) {
  if (!HHMM.test(from || '') || !HHMM.test(to || '')) return 'Set the from and to times';
  if (toMin(to) <= toMin(from)) return 'The end time must be after the start time';
  return null;
}

// The HOD sets the timetable and chooses each period's From and To time while setting it.
// Teachers and students see it (read-only).
export default function Timetable({ user }) {
  const hod = user.role === 'hod';
  const [slots, setSlots] = useState([]);
  const [courses, setCourses] = useState([]);
  const [form, setForm] = useState({ course_id: '', day: '1', from: '', to: '', room: '' });
  const [editing, setEditing] = useState(null); // { id, from, to, room }
  const [msg, setMsg] = useState(null);

  const load = () => api('/api/timetable', { user }).then(setSlots)
    .catch((e) => setMsg({ ok: false, text: e.message }));

  useEffect(() => {
    load();
    if (hod) {
      api('/api/courses', { user }).then((c) => {
        setCourses(c);
        setForm((f) => ({ ...f, course_id: f.course_id || (c[0] ? String(c[0].id) : '') }));
      }).catch(() => {});
    }
  }, [user.id, user.role]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function add() {
    const err = timeError(form.from, form.to);
    if (err) return setMsg({ ok: false, text: err });
    try {
      await api('/api/timetable', {
        method: 'POST', user,
        body: { course_id: Number(form.course_id), day: Number(form.day),
                start_time: form.from, end_time: form.to, room: form.room },
      });
      setMsg({ ok: true, text: 'Period added to the timetable.' });
      setForm((f) => ({ ...f, from: '', to: '', room: '' }));
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  async function saveEdit() {
    const err = timeError(editing.from, editing.to);
    if (err) return setMsg({ ok: false, text: err });
    try {
      await api(`/api/timetable/${editing.id}`, {
        method: 'PUT', user,
        body: { start_time: editing.from, end_time: editing.to, room: editing.room },
      });
      setMsg({ ok: true, text: 'Period updated.' });
      setEditing(null);
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  async function remove(id) {
    if (!window.confirm('Remove this period from the timetable?')) return;
    try {
      await api(`/api/timetable/${id}`, { method: 'DELETE', user });
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  const groups = DAYS.map((name, i) => ({ name, items: slots.filter((s) => s.day === i + 1) }))
    .filter((g) => g.items.length > 0);

  return (
    <div className="p-4">
      {hod && (
        <div className="mb-4 rounded-lg border p-4">
          <h3 className="mb-2 font-semibold">Add a period</h3>
          <select className="mb-2 w-full rounded border p-2" value={form.course_id} onChange={set('course_id')}>
            {courses.map((c) => <option key={c.id} value={c.id}>{c.code} · {c.title}</option>)}
          </select>
          <select className="mb-2 w-full rounded border p-2" value={form.day} onChange={set('day')}>
            {DAYS.map((d, i) => <option key={d} value={i + 1}>{d}</option>)}
          </select>
          <div className="mb-2 flex flex-wrap gap-4">
            <div>
              <p className="mb-1 text-xs text-gray-500">From</p>
              <TimeField label="From" value={form.from} onChange={(v) => setForm((f) => ({ ...f, from: v }))} />
            </div>
            <div>
              <p className="mb-1 text-xs text-gray-500">To</p>
              <TimeField label="To" value={form.to} onChange={(v) => setForm((f) => ({ ...f, to: v }))} />
            </div>
          </div>
          <input className="mb-2 w-full rounded border p-2" placeholder="Room or hall" maxLength={40}
                 value={form.room} onChange={set('room')} />
          <button className="rounded bg-green-600 px-4 py-2 text-white" onClick={add}>Add to timetable</button>
          {msg && <p className={`mt-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
        </div>
      )}

      <h2 className="mb-2 text-lg font-semibold">{hod ? 'Department timetable' : 'Timetable'}</h2>
      {!hod && msg && !msg.ok && <p className="text-sm text-red-600">{msg.text}</p>}
      {groups.length === 0 ? (
        <p className="text-gray-500">No periods in the timetable yet.</p>
      ) : (
        groups.map((g) => (
          <div key={g.name} className="mb-3">
            <p className="mb-1 text-sm font-semibold text-gray-600">{g.name}</p>
            <ul className="divide-y rounded-lg border">
              {g.items.map((s) => (
                <li key={s.id} className="px-4 py-3">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="font-medium">{s.start_time}–{s.end_time} · {s.code}</p>
                      <p className="text-sm text-gray-500">{s.title} · {s.room}</p>
                    </div>
                    {hod && (
                      <div className="flex gap-2">
                        <button className="rounded border px-3 py-1 text-sm"
                                onClick={() => setEditing({ id: s.id, from: s.start_time, to: s.end_time, room: s.room })}>
                          Edit time
                        </button>
                        <button className="rounded border px-3 py-1 text-sm text-red-600" onClick={() => remove(s.id)}>Delete</button>
                      </div>
                    )}
                  </div>
                  {hod && editing && editing.id === s.id && (
                    <div className="mt-2 flex flex-wrap items-end gap-3">
                      <div>
                        <p className="mb-1 text-xs text-gray-500">From</p>
                        <TimeField label="From" value={editing.from} onChange={(v) => setEditing((e) => ({ ...e, from: v }))} />
                      </div>
                      <div>
                        <p className="mb-1 text-xs text-gray-500">To</p>
                        <TimeField label="To" value={editing.to} onChange={(v) => setEditing((e) => ({ ...e, to: v }))} />
                      </div>
                      <input className="rounded border p-2" maxLength={40} value={editing.room}
                             onChange={(e) => setEditing((x) => ({ ...x, room: e.target.value }))} />
                      <button className="rounded bg-green-600 px-3 py-2 text-sm text-white" onClick={saveEdit}>Save</button>
                      <button className="rounded border px-3 py-2 text-sm" onClick={() => setEditing(null)}>Cancel</button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </div>
        ))
      )}
    </div>
  );
}

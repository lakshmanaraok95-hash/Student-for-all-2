import { useState } from 'react';
import { login } from './api.js';

const COPY = {
  student: { title: 'Student', idLabel: 'Roll number', hint: 'For example CS202601' },
  teacher: { title: 'Professor', idLabel: 'Employee ID', hint: 'The ID your college gave you' },
  hod: { title: 'HOD', idLabel: 'Employee ID', hint: 'The ID your college gave you' },
  other: { title: 'Others', idLabel: 'ID', hint: 'Your staff or guest ID' },
};

// The sign-in page for the role chosen on the previous screen.
export default function Login({ role, onBack, onSuccess }) {
  const c = COPY[role];
  const [id, setId] = useState('');
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      onSuccess(await login(role, id.trim(), pw));
    } catch (err) {
      setError(err.message);
      setPw('');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <button className="mb-4 text-sm text-green-700" onClick={onBack}>← Change role</button>
      <h1 className="text-2xl font-bold">Sign in as {c.title}</h1>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <div>
          <label htmlFor="login-id" className="block text-sm font-medium text-gray-700">{c.idLabel}</label>
          <input id="login-id" className="mt-1 w-full rounded-lg border p-3 text-base" autoComplete="username"
                 autoCapitalize="characters" value={id} onChange={(e) => setId(e.target.value)} placeholder={c.hint} />
        </div>
        <div>
          <label htmlFor="login-pw" className="block text-sm font-medium text-gray-700">Password</label>
          <div className="mt-1 flex gap-2">
            <input id="login-pw" className="w-full rounded-lg border p-3 text-base" autoComplete="current-password"
                   type={show ? 'text' : 'password'} value={pw} onChange={(e) => setPw(e.target.value)} />
            <button type="button" className="rounded-lg border px-3 text-sm" onClick={() => setShow((s) => !s)}>
              {show ? 'Hide' : 'Show'}
            </button>
          </div>
        </div>
        {error && <p role="alert" className="rounded bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        <button type="submit" disabled={busy || !id.trim() || !pw}
                className="w-full rounded-lg bg-green-600 px-4 py-3 text-base font-semibold text-white disabled:opacity-50">
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
      <p className="mt-4 text-xs text-gray-500">
        Forgot your password? Ask your administrator to reset it. After 5 wrong tries in a row the account is locked for 15 minutes.
      </p>
    </div>
  );
}

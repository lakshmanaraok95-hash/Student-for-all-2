import { useEffect, useState } from 'react';
import { api } from './api.js';
import TimeField from './TimeField.jsx';

const fmt = (d) => new Date(d + 'T00:00').toLocaleDateString(undefined,
  { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

export default function Exams({ user }) {
  const teacher = user.role === 'teacher';
  const [exams, setExams] = useState([]);
  const [courses, setCourses] = useState([]);
  const [form, setForm] = useState({ course_id: '', exam_date: '', start_time: '', room: '' });
  const [msg, setMsg] = useState(null);

  const load = () => api('/api/exams', { user }).then(setExams)
    .catch((e) => setMsg({ ok: false, text: e.message }));

  useEffect(() => {
    load();
    if (teacher) {
      api('/api/courses', { user }).then((c) => {
        setCourses(c);
        setForm((f) => ({ ...f, course_id: c[0] ? String(c[0].id) : '' }));
      }).catch(() => {});
    }
  }, [user.id, user.role]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function add() {
    try {
      await api('/api/exams', { method: 'POST', user, body: { ...form, course_id: Number(form.course_id) } });
      setMsg({ ok: true, text: 'Exam added. Students can see it now.' });
      setForm((f) => ({ ...f, exam_date: '', start_time: '', room: '' }));
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  async function remove(id) {
    await api(`/api/exams/${id}`, { method: 'DELETE', user });
    load();
  }

  return (
    <div className="p-4">
      {teacher && (
        <div className="mb-4 rounded-lg border p-4">
          <h3 className="mb-2 font-semibold">Add exam</h3>
          <select className="mb-2 w-full rounded border p-2" value={form.course_id} onChange={set('course_id')}>
            {courses.map((c) => <option key={c.id} value={c.id}>{c.code} · {c.title}</option>)}
          </select>
          <input type="date" className="mb-2 w-full rounded border p-2" value={form.exam_date} onChange={set('exam_date')} />
          <p className="mb-1 text-xs text-gray-500">Start time</p>
          <div className="mb-2">
            <TimeField label="Start time" value={form.start_time}
                       onChange={(v) => setForm((f) => ({ ...f, start_time: v }))} />
          </div>
          <input className="mb-2 w-full rounded border p-2" placeholder="Room or hall" maxLength={40}
                 value={form.room} onChange={set('room')} />
          <button className="rounded bg-green-600 px-4 py-2 text-white" onClick={add}>Add exam</button>
          {msg && <p className={`mt-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
        </div>
      )}
      <h2 className="mb-2 text-lg font-semibold">Exam schedule</h2>
      {!teacher && msg && !msg.ok && <p className="text-sm text-red-600">{msg.text}</p>}
      {exams.length === 0 ? (
        <p className="text-gray-500">No exams scheduled.</p>
      ) : (
        <ul className="divide-y rounded-lg border">
          {exams.map((x) => (
            <li key={x.id} className="flex items-center justify-between px-4 py-3">
              <div>
                <p className="font-medium">{x.code} · {x.title}</p>
                <p className="text-sm text-gray-500">{fmt(x.exam_date)} · {x.start_time} · {x.room}</p>
              </div>
              {teacher && (
                <button className="text-sm text-red-600" onClick={() => remove(x.id)}>Delete</button>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

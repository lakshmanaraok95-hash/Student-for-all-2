import { useEffect, useState } from 'react';
import { api } from './api.js';

function Bar({ pct }) {
  return (
    <div className="mt-1 h-2 overflow-hidden rounded bg-gray-200">
      <div className={`h-full ${pct < 75 ? 'bg-red-500' : 'bg-green-600'}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

// Teacher: everyone in the course, lowest first, with low-attendance warnings
export function Analytics({ courseId, user }) {
  const [rows, setRows] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api(`/api/courses/${courseId}/attendance-summary`, { user })
      .then(setRows).catch((e) => setError(e.message));
  }, [courseId, user.id, user.role]);

  const sorted = [...rows].sort((a, b) => a.pct - b.pct);
  const low = sorted.filter((r) => r.low).length;

  return (
    <div className="p-4">
      <h2 className="mb-2 text-lg font-semibold">Attendance analytics</h2>
      {error && <p className="text-sm text-red-600">{error}</p>}
      {low > 0 && (
        <p className="mb-3 rounded bg-red-50 p-2 text-sm text-red-700">
          {low} student{low > 1 ? 's' : ''} below 75% attendance
        </p>
      )}
      <ul className="divide-y rounded-lg border">
        {sorted.map((r) => (
          <li key={r.id} className="px-4 py-3">
            <div className="flex justify-between">
              <span className="font-medium">
                {r.name}
                {r.excused > 0 && <span className="ml-1 text-xs text-gray-500">({r.excused} excused)</span>}
              </span>
              <span className={r.low ? 'font-semibold text-red-600' : ''}>
                {r.pct}%{r.low ? ' (low)' : ''}
              </span>
            </div>
            <Bar pct={r.pct} />
          </li>
        ))}
      </ul>
      <p className="mt-2 text-xs text-gray-500">Excused days are left out of the total.</p>
    </div>
  );
}

// Student: their own numbers
export function MyAttendance({ courseId, user }) {
  const [me, setMe] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api(`/api/me/summary?courseId=${courseId}`, { user })
      .then(setMe).catch((e) => setError(e.message));
  }, [courseId, user.id, user.role]);

  if (error) return <p className="p-4 text-sm text-red-600">{error}</p>;
  if (!me) return <p className="p-4 text-gray-500">No attendance yet.</p>;
  return (
    <div className="p-4">
      <h2 className="mb-2 text-lg font-semibold">My attendance</h2>
      <div className="rounded-lg border p-4">
        <p className={`text-3xl font-bold ${me.low ? 'text-red-600' : 'text-green-700'}`}>{me.pct}%</p>
        {me.low && <p className="text-sm text-red-600">Below the 75% minimum</p>}
        <Bar pct={me.pct} />
        <p className="mt-2 text-sm text-gray-600">
          Present {me.present} of {me.held} classes
          {me.excused > 0 && `, ${me.excused} excused (not counted against you)`}
        </p>
      </div>
    </div>
  );
}

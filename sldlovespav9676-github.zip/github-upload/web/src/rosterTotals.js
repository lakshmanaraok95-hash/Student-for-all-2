// Counts for a class roster. LATE counts as present; everyone else who isn't excused
// is absent (including students who haven't scanned yet).
export function rosterTotals(students) {
  const present = students.filter((s) => s.status === 'PRESENT' || s.status === 'LATE').length;
  const excused = students.filter((s) => s.status === 'EXCUSED').length;
  return { total: students.length, present, excused, absent: students.length - present - excused };
}

import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { api, API, socketAuth } from './api.js';
import QRDisplay from './QRDisplay.jsx';
import StudentScanner from './StudentScanner.jsx';

const TYPES = ['Cultural', 'Sports', 'Workshop', 'Other'];
const fmt = (d) => new Date(d + 'T00:00').toLocaleDateString(undefined,
  { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

// ---------------- Teacher ----------------
export function TeacherEvents({ user }) {
  const [events, setEvents] = useState([]);
  const [sel, setSel] = useState(null);
  const [roster, setRoster] = useState([]);
  const [showQr, setShowQr] = useState(false);
  const [view, setView] = useState('attendance'); // 'attendance' | 'going'
  const [going, setGoing] = useState([]);
  const [dutyMsg, setDutyMsg] = useState(null);
  const [form, setForm] = useState({ name: '', type: 'Cultural', event_date: '', loc: null });
  const [msg, setMsg] = useState(null);

  const loadEvents = () => api('/api/events', { user }).then((ev) => {
    setEvents(ev);
    setSel((s) => (s && ev.some((e) => e.id === s) ? s : ev[0]?.id ?? null));
  }).catch((e) => setMsg({ ok: false, text: e.message }));

  useEffect(() => { loadEvents(); }, [user.id]);

  // Roster for the selected event, kept live over the socket
  useEffect(() => {
    setShowQr(false);
    setDutyMsg(null);
    if (sel == null) { setRoster([]); setGoing([]); return undefined; }
    api(`/api/events/${sel}/attendance`, { user }).then(setRoster).catch(() => {});
    api(`/api/events/${sel}/participants`, { user }).then(setGoing).catch(() => {});
    const socket = io(API, { auth: socketAuth() });
    socket.emit('join-event', sel);
    socket.on('event-attendance', ({ studentId, attended }) => {
      setRoster((prev) => prev.map((s) => (s.id === studentId ? { ...s, attended } : s)));
    });
    return () => socket.disconnect();
  }, [sel]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  function useMyLocation() {
    if (!navigator.geolocation) return setMsg({ ok: false, text: 'Location not supported here' });
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setForm((f) => ({ ...f, loc: { lat: p.coords.latitude, lng: p.coords.longitude } }));
        setMsg({ ok: true, text: 'Venue location saved for this event.' });
      },
      () => setMsg({ ok: false, text: 'Location blocked. Allow it, or skip the location check.' }),
      { enableHighAccuracy: true, timeout: 10000 });
  }

  async function addEvent() {
    try {
      const body = { name: form.name, type: form.type, event_date: form.event_date,
        room_lat: form.loc?.lat, room_lng: form.loc?.lng };
      const created = await api('/api/events', { method: 'POST', user, body });
      setForm({ name: '', type: 'Cultural', event_date: '', loc: null });
      setMsg({ ok: true, text: 'Event added.' });
      setSel(created.id);
      loadEvents();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  async function removeEvent() {
    await api(`/api/events/${sel}`, { method: 'DELETE', user });
    setSel(null);
    loadEvents();
  }

  async function toggle(s) {
    const attended = !s.attended;
    setRoster((prev) => prev.map((x) => (x.id === s.id ? { ...x, attended } : x)));
    try {
      await api(`/api/events/${sel}/attendance/${s.id}`, { method: 'PUT', user, body: { attended } });
      loadEvents();
    } catch {
      setRoster((prev) => prev.map((x) => (x.id === s.id ? { ...x, attended: !attended } : x)));
      setMsg({ ok: false, text: 'Save failed, change reverted' });
    }
  }

  async function toggleGoing(s) {
    const next = !s.going;
    setGoing((prev) => prev.map((x) => (x.id === s.id ? { ...x, going: next } : x)));
    try {
      await api(`/api/events/${sel}/participants/${s.id}`, { method: 'PUT', user, body: { going: next } });
      loadEvents();
    } catch {
      setGoing((prev) => prev.map((x) => (x.id === s.id ? { ...x, going: !next } : x)));
      setDutyMsg({ ok: false, text: 'Save failed, change reverted' });
    }
  }

  async function applyOnDuty() {
    try {
      const r = await api(`/api/events/${sel}/on-duty`, { method: 'POST', user });
      setDutyMsg({ ok: true, text: r.updated
        ? `Done. ${r.updated} class record${r.updated > 1 ? 's' : ''} marked excused (on duty).`
        : 'No classes found on the event date for these students, so nothing changed.' });
    } catch (e) {
      setDutyMsg({ ok: false, text: e.message });
    }
  }

  async function undoOnDuty() {
    if (!window.confirm('Undo on-duty for this event? Classes it excused go back to absent.')) return;
    try {
      const r = await api(`/api/events/${sel}/on-duty`, { method: 'DELETE', user });
      setDutyMsg({ ok: true, text: r.updated
        ? `Undone. ${r.updated} class record${r.updated > 1 ? 's' : ''} set back to absent.`
        : 'Nothing to undo for this event.' });
    } catch (e) {
      setDutyMsg({ ok: false, text: e.message });
    }
  }

  const current = events.find((e) => e.id === sel);
  const count = roster.filter((s) => s.attended).length;

  return (
    <div className="p-4">
      <div className="mb-4 rounded-lg border p-4">
        <h3 className="mb-2 font-semibold">Add college event</h3>
        <input className="mb-2 w-full rounded border p-2" placeholder="Event name" maxLength={60}
               value={form.name} onChange={set('name')} />
        <select className="mb-2 w-full rounded border p-2" value={form.type} onChange={set('type')}>
          {TYPES.map((t) => <option key={t}>{t}</option>)}
        </select>
        <input type="date" className="mb-2 w-full rounded border p-2" value={form.event_date} onChange={set('event_date')} />
        <button className="mb-2 rounded border px-3 py-2 text-sm" onClick={useMyLocation}>
          {form.loc ? 'Location saved ✓' : 'Use my location as the venue (optional)'}
        </button>
        <div>
          <button className="rounded bg-green-600 px-4 py-2 text-white" onClick={addEvent}>Add event</button>
        </div>
        {msg && <p className={`mt-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
      </div>

      {current ? (
        <div className="rounded-lg border p-4">
          <select className="mb-2 w-full rounded border p-2" value={sel}
                  onChange={(e) => setSel(Number(e.target.value))}>
            {events.map((e) => <option key={e.id} value={e.id}>{e.name} ({e.type})</option>)}
          </select>
          <div className="mb-2 flex items-center justify-between">
            <span className="font-medium">{fmt(current.event_date)}</span>
            <span className="text-sm text-gray-600">{count} / {roster.length} attended</span>
          </div>
          <div className="mb-2 flex gap-2">
            <button className="rounded border px-3 py-1 text-sm" onClick={() => setShowQr((v) => !v)}>
              {showQr ? 'Hide QR' : 'Show check-in QR'}
            </button>
            <button className="rounded border px-3 py-1 text-sm text-red-600" onClick={removeEvent}>
              Delete event
            </button>
          </div>
          {!current.has_location && showQr && (
            <p className="mb-2 text-xs text-amber-700">This event has no venue location, so there is no distance check.</p>
          )}
          {showQr && <QRDisplay teacherId={user.id} path={`/api/events/${sel}/qr`} />}
          <div className="mb-2 flex gap-2 text-sm">
            <button onClick={() => setView('attendance')}
              className={`rounded-full border px-3 py-1 ${view === 'attendance' ? 'border-green-600 bg-green-50 text-green-700' : 'text-gray-600'}`}>
              Attended
            </button>
            <button onClick={() => setView('going')}
              className={`rounded-full border px-3 py-1 ${view === 'going' ? 'border-green-600 bg-green-50 text-green-700' : 'text-gray-600'}`}>
              Going for the college ({going.filter((g) => g.going).length})
            </button>
          </div>
          {view === 'attendance' ? (
          <ul className="divide-y">
            {roster.map((s) => (
              <li key={s.id} className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">{s.name}</p>
                  <p className="text-xs text-gray-500">{s.roll_no}</p>
                </div>
                <input type="checkbox" className="h-5 w-5 accent-green-600"
                       checked={s.attended} onChange={() => toggle(s)} />
              </li>
            ))}
          </ul>
          ) : (
            <div>
              <p className="mb-2 text-xs text-gray-500">
                Tick the students going to this event on behalf of the college. Then apply on-duty
                to excuse their classes on {fmt(current.event_date)}. Students who actually attended
                class that day are left alone.
              </p>
              <ul className="divide-y">
                {going.map((s) => (
                  <li key={s.id} className="flex items-center justify-between py-2">
                    <div>
                      <p className="font-medium">{s.name}</p>
                      <p className="text-xs text-gray-500">{s.roll_no}</p>
                    </div>
                    <input type="checkbox" className="h-5 w-5 accent-green-600"
                           checked={s.going} onChange={() => toggleGoing(s)} />
                  </li>
                ))}
              </ul>
              <div className="mt-3 flex gap-2">
                <button className="rounded bg-green-600 px-4 py-2 text-white" onClick={applyOnDuty}>
                  Apply on-duty to class
                </button>
                <button className="rounded border px-4 py-2 text-sm" onClick={undoOnDuty}>
                  Undo on-duty
                </button>
              </div>
              {dutyMsg && (
                <p className={`mt-2 text-sm ${dutyMsg.ok ? 'text-green-700' : 'text-red-600'}`}>{dutyMsg.text}</p>
              )}
            </div>
          )}
        </div>
      ) : (
        <p className="text-gray-500">No events yet. Add the first one above.</p>
      )}
    </div>
  );
}

// ---------------- Student ----------------
export function StudentEvents({ user }) {
  const [events, setEvents] = useState([]);
  const [scanId, setScanId] = useState(null);
  const [error, setError] = useState('');

  const load = () => api('/api/events', { user }).then(setEvents).catch((e) => setError(e.message));
  useEffect(() => { load(); }, [user.id]);

  if (scanId != null) {
    const ev = events.find((e) => e.id === scanId);
    return (
      <div className="p-4">
        <button className="mb-2 text-sm text-green-700" onClick={() => { setScanId(null); load(); }}>
          ← Back to events
        </button>
        <p className="text-center font-medium">{ev ? ev.name : 'Event'}</p>
        <StudentScanner studentId={user.id} endpoint="/api/events/scan" onDone={load} />
      </div>
    );
  }

  const n = events.filter((e) => e.attended).length;
  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold">College events</h2>
      <p className="mb-2 text-sm text-gray-600">You have attended {n} of {events.length} events.</p>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <ul className="divide-y rounded-lg border">
        {events.map((e) => (
          <li key={e.id} className="flex items-center justify-between px-4 py-3">
            <div>
              <p className="font-medium">
                {e.name}
                {e.going && (
                  <span className="ml-2 rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-800">
                    Representing the college
                  </span>
                )}
              </p>
              <p className="text-sm text-gray-500">{e.type} · {fmt(e.event_date)}</p>
            </div>
            {e.attended ? (
              <span className="rounded-full bg-green-100 px-2 py-1 text-xs text-green-800">Attended</span>
            ) : (
              <button className="rounded bg-green-600 px-3 py-2 text-sm text-white"
                      onClick={() => setScanId(e.id)}>Scan QR</button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

import { useState } from 'react';
import { api } from './api.js';

// Opened from the menu: change your own password.
export default function ChangePassword({ onClose }) {
  const [f, setF] = useState({ current: '', next: '', again: '' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }));

  async function save(e) {
    e.preventDefault();
    if (f.next !== f.again) return setMsg({ ok: false, text: 'The two new passwords are not the same' });
    setBusy(true);
    try {
      await api('/api/auth/change-password', { method: 'POST', body: { current_password: f.current, new_password: f.next } });
      setMsg({ ok: true, text: 'Password changed.' });
      setF({ current: '', next: '', again: '' });
    } catch (err) {
      setMsg({ ok: false, text: err.message });
    } finally {
      setBusy(false);
    }
  }

  const field = (id, label, key, auto) => (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700">{label}</label>
      <input id={id} type="password" autoComplete={auto} className="mt-1 w-full rounded-lg border p-3"
             value={f[key]} onChange={set(key)} />
    </div>
  );

  return (
    <main className="bg-white p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Change password</h2>
        <button className="rounded border px-3 py-1 text-sm" onClick={onClose}>Back to app</button>
      </div>
      <form onSubmit={save} className="space-y-3">
        {field('pw-cur', 'Current password', 'current', 'current-password')}
        {field('pw-new', 'New password', 'next', 'new-password')}
        {field('pw-again', 'New password again', 'again', 'new-password')}
        <p className="text-xs text-gray-500">At least 8 characters, with letters and at least one number.</p>
        <button type="submit" disabled={busy} className="rounded bg-green-600 px-4 py-2 text-white disabled:opacity-50">
          Change password
        </button>
        {msg && <p className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
      </form>
    </main>
  );
}

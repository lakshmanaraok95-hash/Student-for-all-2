// Shared fetch helper. With the Vite proxy, API is '' (same origin).
export const API = import.meta.env.VITE_API_URL ?? '';

// The sign-in token lives in sessionStorage: it is forgotten when the tab is closed, which is
// safer on a shared tablet than keeping it for good.
const KEY = 'attendance-token';
export function getToken() {
  try { return window.sessionStorage.getItem(KEY) || ''; } catch { return ''; }
}
export function setToken(token) {
  try {
    if (token) window.sessionStorage.setItem(KEY, token); else window.sessionStorage.removeItem(KEY);
  } catch { /* storage blocked: the user simply signs in again next time */ }
}
export const authHeaders = () => (getToken() ? { Authorization: `Bearer ${getToken()}` } : {});
export const socketAuth = () => ({ token: getToken() });

// Every request after sign-in goes through here. (A leftover { user } option is ignored: who you
// are now comes from the signed token, not from anything the browser says.)
export async function api(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(API + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    window.dispatchEvent(new Event('app-offline'));
    throw new Error('No connection. Check your internet and try again.');
  }
  window.dispatchEvent(new Event('app-online'));
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (res.status === 401 && getToken()) {
    setToken('');
    window.dispatchEvent(new Event('auth-expired')); // the sign-in ran out: back to the start
  }
  if (!res.ok) throw new Error((data && data.error) || 'Request failed');
  return data;
}

// Signing in (no token yet).
export async function login(role, loginId, password) {
  let res;
  try {
    res = await fetch(`${API}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role, login_id: loginId, password }),
    });
  } catch {
    throw new Error('No connection. Check your internet and try again.');
  }
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new Error((data && data.error) || 'Could not sign in');
  return data;
}

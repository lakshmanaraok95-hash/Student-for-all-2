import { useEffect, useState } from 'react';

// true while the browser is online AND the last request to our server worked.
// api.js fires 'app-offline' / 'app-online' so a down server is detected too.
export function useConnection() {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine);
  useEffect(() => {
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    const pairs = [['online', up], ['offline', down], ['app-online', up], ['app-offline', down]];
    pairs.forEach(([n, f]) => window.addEventListener(n, f));
    return () => pairs.forEach(([n, f]) => window.removeEventListener(n, f));
  }, []);
  return online;
}

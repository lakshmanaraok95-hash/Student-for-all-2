import { useEffect, useState } from 'react';
import { api } from './api.js';

const time = (iso) => new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

// Head of department: attendance across every course, students below 75%, recent classes.
export default function HodOverview({ user }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api('/api/hod/overview', { user }).then(setData).catch((e) => setError(e.message));
  }, [user.id, user.role]);

  if (error) return <p className="p-4 text-sm text-red-600">{error}</p>;
  if (!data) return <p className="p-4 text-gray-500">Loading…</p>;

  const lowTotal = data.courses.reduce((n, c) => n + c.low.length, 0);

  return (
    <div className="p-4">
      <h2 className="mb-1 text-lg font-semibold">Department overview</h2>
      <p className="mb-3 text-sm text-gray-600">
        {data.courses.length} course{data.courses.length === 1 ? '' : 's'} · {lowTotal} student
        {lowTotal === 1 ? '' : 's'} below 75% in at least one course
      </p>

      <div className="space-y-3">
        {data.courses.map((c) => (
          <div key={c.id} className="rounded-lg border p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-medium">{c.code} · {c.title}</p>
                <p className="text-sm text-gray-500">Teacher #{c.teacher_id} · {c.enrolled} students</p>
              </div>
              <p className={`text-2xl font-bold ${c.avg_pct != null && c.avg_pct < 75 ? 'text-red-600' : 'text-green-700'}`}>
                {c.avg_pct == null ? '–' : `${c.avg_pct}%`}
              </p>
            </div>
            {c.low.length > 0 ? (
              <ul className="mt-2 divide-y text-sm">
                {c.low.map((s) => (
                  <li key={s.id} className="flex justify-between py-1">
                    <span>{s.name} <span className="text-xs text-gray-500">{s.roll_no}</span></span>
                    <span className="font-semibold text-red-600">{s.pct}%</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-2 text-sm text-gray-500">No students below 75%.</p>
            )}
          </div>
        ))}
      </div>

      <h3 className="mb-2 mt-5 font-semibold">Classes in the last 24 hours</h3>
      {data.recent.length === 0 ? (
        <p className="text-sm text-gray-500">No classes held.</p>
      ) : (
        <ul className="divide-y rounded-lg border">
          {data.recent.map((r) => (
            <li key={r.id} className="flex items-center justify-between px-4 py-2 text-sm">
              <span>{r.code} · {time(r.starts_at)}–{time(r.ends_at)}</span>
              <span className="text-gray-600">{r.is_open ? 'Open' : 'Ended'} · {r.present}/{r.enrolled} present</span>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-2 text-xs text-gray-500">Attendance % leaves out excused days.</p>
    </div>
  );
}

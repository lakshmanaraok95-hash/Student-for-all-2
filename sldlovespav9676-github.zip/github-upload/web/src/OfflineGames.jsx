import { useEffect, useRef, useState } from 'react';

// Three small mind games. Everything runs in the browser: no network needed.

const rnd = (n) => Math.floor(Math.random() * n);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const btn = 'rounded bg-green-600 px-4 py-2 text-white';

/* ---------------- 1. Memory Match ---------------- */
const EMOJI = ['🍎', '🚀', '🎧', '🌙', '🔥', '🎲', '🌵', '🐢'];

function deal() {
  const a = [...EMOJI, ...EMOJI].map((e) => ({ e, open: false, done: false }));
  for (let i = a.length - 1; i > 0; i--) {
    const j = rnd(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function MemoryMatch() {
  const [cards, setCards] = useState(deal);
  const [picked, setPicked] = useState([]);
  const [moves, setMoves] = useState(0);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  function flip(i) {
    if (picked.length === 2 || cards[i].open || cards[i].done) return;
    const next = cards.map((c, k) => (k === i ? { ...c, open: true } : c));
    const p = [...picked, i];
    setCards(next);
    setPicked(p);
    if (p.length === 2) {
      setMoves((m) => m + 1);
      const [a, b] = p;
      const hit = next[a].e === next[b].e;
      timers.current.push(setTimeout(() => {
        setCards((cs) => cs.map((c, k) => (k === a || k === b
          ? (hit ? { ...c, done: true } : { ...c, open: false }) : c)));
        setPicked([]);
      }, hit ? 300 : 800));
    }
  }

  function again() {
    setCards(deal());
    setPicked([]);
    setMoves(0);
  }

  const won = cards.every((c) => c.done);
  return (
    <div>
      <p className="mb-2 text-sm text-gray-600">
        Find all 8 pairs. Moves: {moves}{won ? ` · You won in ${moves} moves! 🎉` : ''}
      </p>
      <div className="grid max-w-xs grid-cols-4 gap-2">
        {cards.map((c, i) => (
          <button key={i} onClick={() => flip(i)}
            className={`aspect-square rounded-lg border text-3xl ${c.done ? 'bg-green-50' : 'bg-white'}`}>
            {c.open || c.done ? c.e : '?'}
          </button>
        ))}
      </div>
      <button className={`mt-3 ${btn}`} onClick={again}>New game</button>
    </div>
  );
}

/* ---------------- 2. Quick Math ---------------- */
function newQ() {
  const op = ['+', '-', '×'][rnd(3)];
  let a = 2 + rnd(18);
  let b = 2 + rnd(18);
  if (op === '×') { a = 2 + rnd(11); b = 2 + rnd(11); }
  if (op === '-' && b > a) [a, b] = [b, a];
  return { text: `${a} ${op} ${b}`, answer: op === '+' ? a + b : op === '-' ? a - b : a * b };
}

function QuickMath() {
  const [phase, setPhase] = useState('idle'); // idle | play | over
  const [time, setTime] = useState(30);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [q, setQ] = useState(newQ);
  const [input, setInput] = useState('');
  const scoreRef = useRef(0);

  useEffect(() => {
    if (phase !== 'play') return undefined;
    const id = setInterval(() => setTime((t) => t - 1), 1000);
    return () => clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase === 'play' && time <= 0) {
      setPhase('over');
      setBest((b) => Math.max(b, scoreRef.current));
    }
  }, [time, phase]);

  function start() {
    scoreRef.current = 0;
    setScore(0);
    setTime(30);
    setQ(newQ());
    setInput('');
    setPhase('play');
  }

  function submit(e) {
    e.preventDefault();
    if (input.trim() !== '' && Number(input) === q.answer) {
      scoreRef.current += 1;
      setScore(scoreRef.current);
    }
    setQ(newQ());
    setInput('');
  }

  if (phase !== 'play') {
    return (
      <div>
        <p className="mb-2 text-sm text-gray-600">Answer as many as you can in 30 seconds.</p>
        {phase === 'over' && <p className="mb-2 font-medium">Time's up! Score: {score} (best {best})</p>}
        <button className={btn} onClick={start}>{phase === 'over' ? 'Play again' : 'Start'}</button>
      </div>
    );
  }
  return (
    <form onSubmit={submit}>
      <p className="text-sm text-gray-600">Time {time}s · Score {score}</p>
      <p className="my-3 text-3xl font-semibold">{q.text} = ?</p>
      <input autoFocus inputMode="numeric" className="mr-2 w-32 rounded border p-2"
             value={input} onChange={(e) => setInput(e.target.value)} />
      <button type="submit" className={btn}>Answer</button>
    </form>
  );
}

/* ---------------- 3. Sequence Memory ---------------- */
const PADS = ['#e5534b', '#3b82f6', '#22a65a', '#eab308'];

function SequenceMemory() {
  const [seq, setSeq] = useState([]);
  const [step, setStep] = useState(0);
  const [phase, setPhase] = useState('idle'); // idle | show | input | over
  const [lit, setLit] = useState(-1);
  const [best, setBest] = useState(0);
  const alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; };
  }, []);

  async function show(s) {
    setPhase('show');
    setStep(0);
    await wait(500);
    for (const p of s) {
      if (!alive.current) return;
      setLit(p);
      await wait(450);
      setLit(-1);
      await wait(200);
    }
    if (alive.current) setPhase('input');
  }

  function start() {
    const s = [rnd(4)];
    setSeq(s);
    show(s);
  }

  function press(p) {
    if (phase !== 'input') return;
    setLit(p);
    setTimeout(() => alive.current && setLit(-1), 150);
    if (p !== seq[step]) {
      setBest((b) => Math.max(b, seq.length - 1));
      setPhase('over');
      return;
    }
    if (step + 1 === seq.length) {
      const s = [...seq, rnd(4)];
      setSeq(s);
      setPhase('show');
      setTimeout(() => alive.current && show(s), 600);
    } else {
      setStep(step + 1);
    }
  }

  const label = {
    idle: 'Watch the pattern, then repeat it.',
    show: 'Watch…',
    input: 'Your turn!',
    over: `Game over. You completed ${Math.max(0, seq.length - 1)} level${seq.length - 1 === 1 ? '' : 's'}.`,
  }[phase];

  return (
    <div>
      <p className="mb-2 text-sm text-gray-600">{label} Level {Math.max(1, seq.length)} · best {best}</p>
      <div className="grid max-w-[16rem] grid-cols-2 gap-3">
        {PADS.map((c, i) => (
          <button key={c} onClick={() => press(i)} aria-label={`pad ${i + 1}`}
            className="aspect-square rounded-xl border"
            style={{ background: c, opacity: lit === i ? 1 : 0.45 }} />
        ))}
      </div>
      {(phase === 'idle' || phase === 'over') && (
        <button className={`mt-3 ${btn}`} onClick={start}>{phase === 'idle' ? 'Start' : 'Play again'}</button>
      )}
    </div>
  );
}

/* ---------------- Container ---------------- */
const GAMES = [['memory', 'Memory Match'], ['math', 'Quick Math'], ['sequence', 'Sequence']];

export default function OfflineGames({ online, onClose }) {
  const [game, setGame] = useState('memory');
  return (
    <main className="bg-white p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Mind games</h2>
        <button className="rounded border px-3 py-1 text-sm" onClick={onClose}>Back to app</button>
      </div>
      <p className={`mb-3 rounded p-2 text-sm ${online ? 'bg-green-50 text-green-800' : 'bg-amber-50 text-amber-800'}`}>
        {online ? "You're back online. Tap Back to app when you're ready."
                : 'No internet right now. These games work without it.'}
      </p>
      <div className="mb-4 flex gap-2">
        {GAMES.map(([k, label]) => (
          <button key={k} onClick={() => setGame(k)}
            className={`rounded-full border px-3 py-1 text-sm ${game === k ? 'border-green-600 bg-green-50 text-green-700' : 'text-gray-600'}`}>
            {label}
          </button>
        ))}
      </div>
      {game === 'memory' && <MemoryMatch />}
      {game === 'math' && <QuickMath />}
      {game === 'sequence' && <SequenceMemory />}
    </main>
  );
}

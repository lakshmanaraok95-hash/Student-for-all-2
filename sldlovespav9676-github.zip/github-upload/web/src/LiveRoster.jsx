import { useCallback, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { api, API, socketAuth } from './api.js';

const REASONS = ['Medical', 'Family emergency', 'College event / sports', 'Other'];

export default function LiveRoster({ sessionId, teacherId }) {
  const user = { id: teacherId, role: 'teacher' };
  const [students, setStudents] = useState([]);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [reason, setReason] = useState(REASONS[0]);
  const [excuseId, setExcuseId] = useState('');
  const [excuseMsg, setExcuseMsg] = useState(null);

  const load = useCallback(() => {
    api(`/api/sessions/${sessionId}/roster`, { user })
      .then((rows) => {
        setStudents(rows);
        setExcuseId((cur) => cur || (rows[0] ? String(rows[0].id) : ''));
      })
      .catch((e) => setError(e.message));
  }, [sessionId, teacherId]);

  useEffect(load, [load]);

  // Live updates: a QR scan elsewhere flips a row here instantly
  useEffect(() => {
    const socket = io(API, { auth: socketAuth() });
    socket.emit('join', sessionId);
    socket.on('attendance', ({ studentId, status, method, excuse_reason }) => {
      setStudents((prev) => prev.map((s) =>
        s.id === studentId
          ? { ...s, status, method, excuse_reason: excuse_reason ?? null,
              excuse_note: status === 'EXCUSED' ? s.excuse_note : null }
          : s));
    });
    return () => socket.disconnect();
  }, [sessionId]);

  // Manual override: update the UI at once, roll back if the save fails
  async function toggle(student) {
    const next = student.status === 'PRESENT' ? 'ABSENT' : 'PRESENT';
    const before = students;
    setStudents((prev) => prev.map((s) => (s.id === student.id
      ? { ...s, status: next, method: 'MANUAL_OVERRIDE', excuse_reason: null, excuse_note: null } : s)));
    try {
      await api(`/api/sessions/${sessionId}/attendance/${student.id}`,
        { method: 'PUT', user, body: { status: next } });
      setError('');
    } catch {
      setStudents(before);
      setError('Save failed, change reverted');
    }
  }

  async function markExcused() {
    try {
      await api(`/api/sessions/${sessionId}/excuse/${excuseId}`,
        { method: 'PUT', user, body: { reason, note } });
      const who = students.find((s) => String(s.id) === excuseId);
      setExcuseMsg({ ok: true, text: `${who ? who.name : 'Student'} marked excused (${reason}).` });
      setNote('');
      load();
    } catch (e) {
      setExcuseMsg({ ok: false, text: e.message });
    }
  }

  const present = students.filter((s) => s.status === 'PRESENT').length;
  const excused = students.filter((s) => s.status === 'EXCUSED').length;

  return (
    <div className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Live Attendance</h2>
        <span className="text-sm text-gray-600">
          {present} / {students.length} present{excused ? ` · ${excused} excused` : ''}
        </span>
      </div>
      {error && <p className="mb-2 text-sm text-red-600">{error}</p>}
      <ul className="divide-y rounded-lg border">
        {students.map((s) => (
          <li key={s.id} className="flex items-center justify-between px-4 py-3">
            <div>
              <p className="font-medium">
                {s.name}
                {s.status === 'EXCUSED' && (
                  <span className="ml-2 rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-800">
                    Excused: {s.excuse_reason}
                  </span>
                )}
              </p>
              <p className="text-xs text-gray-500">
                {s.roll_no}
                {s.status !== 'EXCUSED' && s.method && ` · ${s.method === 'QR' ? 'QR scan' : 'Manual'}`}
                {s.status === 'EXCUSED' && s.excuse_note && ` · ${s.excuse_note}`}
              </p>
            </div>
            <input
              type="checkbox"
              className="h-5 w-5 accent-green-600"
              checked={s.status === 'PRESENT'}
              onChange={() => toggle(s)}
            />
          </li>
        ))}
      </ul>

      <div className="mt-4 rounded-lg border p-4">
        <h3 className="font-semibold">Excused absence</h3>
        <p className="mb-2 text-xs text-gray-500">
          For students who are unwell or have another valid reason. Excused days don't count
          against their attendance %. Don't write diagnoses in the note.
        </p>
        <select className="mb-2 w-full rounded border p-2" value={excuseId}
                onChange={(e) => setExcuseId(e.target.value)}>
          {students.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <select className="mb-2 w-full rounded border p-2" value={reason}
                onChange={(e) => setReason(e.target.value)}>
          {REASONS.map((r) => <option key={r}>{r}</option>)}
        </select>
        <input className="mb-2 w-full rounded border p-2" maxLength={80}
               placeholder="Short note (optional)" value={note}
               onChange={(e) => setNote(e.target.value)} />
        <button className="rounded bg-green-600 px-4 py-2 text-white" onClick={markExcused}>
          Mark excused today
        </button>
        {excuseMsg && (
          <p className={`mt-2 text-sm ${excuseMsg.ok ? 'text-green-700' : 'text-red-600'}`}>
            {excuseMsg.text}
          </p>
        )}
      </div>
    </div>
  );
}

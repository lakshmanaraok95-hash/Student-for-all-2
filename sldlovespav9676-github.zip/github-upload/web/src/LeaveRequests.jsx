import { useEffect, useState } from 'react';
import { api } from './api.js';

const CATEGORIES = ['Medical', 'Family emergency', 'Other'];
const STYLE = {
  PENDING: 'bg-amber-100 text-amber-800',
  APPROVED: 'bg-green-100 text-green-800',
  REJECTED: 'bg-red-100 text-red-700',
};
const fmt = (d) => new Date(d + 'T00:00').toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
const range = (r) => (r.from_date === r.to_date ? fmt(r.from_date) : `${fmt(r.from_date)} – ${fmt(r.to_date)}`);

function Status({ value }) {
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs ${STYLE[value]}`}>{value.toLowerCase()}</span>
  );
}

// ---------------- Teacher: review requests ----------------
export function TeacherLeave({ user }) {
  const [rows, setRows] = useState([]);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => api('/api/leave-requests', { user }).then(setRows)
    .catch((e) => setMsg({ ok: false, text: e.message }));
  useEffect(() => { load(); }, [user.id]);

  async function decide(r, decision) {
    setBusy(true);
    try {
      const out = await api(`/api/leave-requests/${r.id}/decision`,
        { method: 'PUT', user, body: { decision } });
      setMsg({
        ok: true,
        text: decision === 'APPROVED'
          ? `${r.name}: approved. ${out.updated} class record${out.updated === 1 ? '' : 's'} excused.`
          : `${r.name}: rejected.`,
      });
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
      load();
    } finally {
      setBusy(false);
    }
  }

  const pending = rows.filter((r) => r.status === 'PENDING').length;

  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold">Leave requests</h2>
      <p className="mb-2 text-sm text-gray-600">
        {pending} waiting. Approving excuses the student's classes on those dates.
      </p>
      {msg && <p className={`mb-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
      {rows.length === 0 ? (
        <p className="text-gray-500">No leave requests.</p>
      ) : (
        <ul className="divide-y rounded-lg border">
          {rows.map((r) => (
            <li key={r.id} className="px-4 py-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-medium">{r.name} <span className="text-xs text-gray-500">{r.roll_no}</span></p>
                  <p className="text-sm text-gray-600">{range(r)} · {r.category}</p>
                  {r.reason && <p className="text-sm text-gray-500">{r.reason}</p>}
                </div>
                <Status value={r.status} />
              </div>
              {r.status === 'PENDING' && (
                <div className="mt-2 flex gap-2">
                  <button disabled={busy} className="rounded bg-green-600 px-3 py-1 text-sm text-white disabled:opacity-50"
                          onClick={() => decide(r, 'APPROVED')}>Approve</button>
                  <button disabled={busy} className="rounded border px-3 py-1 text-sm text-red-600 disabled:opacity-50"
                          onClick={() => decide(r, 'REJECTED')}>Reject</button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ---------------- Student: ask for leave, see answers ----------------
export function StudentLeave({ user }) {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ from_date: '', to_date: '', category: CATEGORIES[0], reason: '' });
  const [msg, setMsg] = useState(null);

  const load = () => api('/api/leave-requests', { user }).then(setRows)
    .catch((e) => setMsg({ ok: false, text: e.message }));
  useEffect(() => { load(); }, [user.id]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function send() {
    try {
      await api('/api/leave-requests', { method: 'POST', user, body: form });
      setMsg({ ok: true, text: 'Request sent. Your professor will review it.' });
      setForm((f) => ({ ...f, from_date: '', to_date: '', reason: '' }));
      load();
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  return (
    <div className="p-4">
      <div className="mb-4 rounded-lg border p-4">
        <h3 className="mb-2 font-semibold">Request leave</h3>
        <label className="text-xs text-gray-500">From</label>
        <input type="date" className="mb-2 w-full rounded border p-2" value={form.from_date} onChange={set('from_date')} />
        <label className="text-xs text-gray-500">To</label>
        <input type="date" className="mb-2 w-full rounded border p-2" value={form.to_date} onChange={set('to_date')} />
        <select className="mb-2 w-full rounded border p-2" value={form.category} onChange={set('category')}>
          {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <input className="mb-1 w-full rounded border p-2" maxLength={200}
               placeholder="Short reason (optional)" value={form.reason} onChange={set('reason')} />
        <p className="mb-2 text-xs text-gray-500">The type is enough. Please don't write medical details.</p>
        <button className="rounded bg-green-600 px-4 py-2 text-white" onClick={send}>Send request</button>
        {msg && <p className={`mt-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
      </div>

      <h2 className="mb-2 text-lg font-semibold">My requests</h2>
      {rows.length === 0 ? (
        <p className="text-gray-500">No requests yet.</p>
      ) : (
        <ul className="divide-y rounded-lg border">
          {rows.map((r) => (
            <li key={r.id} className="flex items-center justify-between px-4 py-3">
              <div>
                <p className="font-medium">{range(r)}</p>
                <p className="text-sm text-gray-500">{r.category}{r.reason ? ` · ${r.reason}` : ''}</p>
              </div>
              <Status value={r.status} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

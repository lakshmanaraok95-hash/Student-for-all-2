import { useEffect, useState } from 'react';
import { api } from './api.js';

const CATEGORIES = ['App problem', 'Suggestion', 'Other'];
const when = (iso) => new Date(iso).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

// Opened from the menu. Report a problem with the app or suggest something.
// Each person can send 2 messages every 2 days (the server enforces it).
export default function Feedback({ user, onClose }) {
  const [info, setInfo] = useState(null);
  const [form, setForm] = useState({ category: CATEGORIES[0], message: '' });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = () => api('/api/feedback/mine', { user }).then(setInfo)
    .catch((e) => setMsg({ ok: false, text: e.message }));
  useEffect(() => { load(); }, [user.id, user.role]);

  async function send() {
    setBusy(true);
    try {
      await api('/api/feedback', { method: 'POST', user, body: form });
      setMsg({ ok: true, text: 'Thank you. Your feedback was sent.' });
      setForm((f) => ({ ...f, message: '' }));
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    } finally {
      setBusy(false);
      load();
    }
  }

  const left = info ? info.remaining : null;

  return (
    <main className="bg-white p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Feedback</h2>
        <button className="rounded border px-3 py-1 text-sm" onClick={onClose}>Back to app</button>
      </div>
      <p className="mb-3 rounded bg-gray-50 p-3 text-sm text-gray-700">
        Tell us about a problem with the app or an idea to improve it. You can send 2 messages every 2 days.
        {info && (left > 0
          ? ` You have ${left} of ${info.limit} left.`
          : ` You have used both. You can send again after ${when(info.next_at)}.`)}
      </p>

      <label className="text-xs text-gray-500" htmlFor="fb-cat">What is it about?</label>
      <select id="fb-cat" className="mb-3 mt-1 w-full rounded border p-2" value={form.category}
              onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}>
        {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
      </select>

      <label className="text-xs text-gray-500" htmlFor="fb-msg">Your message</label>
      <textarea id="fb-msg" rows={5} maxLength={500} className="mb-1 mt-1 w-full rounded border p-2"
                placeholder="What happened? Which screen were you on?"
                value={form.message} onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))} />
      <p className="mb-3 text-right text-xs text-gray-400">{form.message.length}/500</p>

      <button disabled={busy || left === 0} onClick={send}
              className="rounded bg-green-600 px-4 py-2 text-white disabled:opacity-50">Send feedback</button>
      {msg && <p className={`mt-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}

      {info && info.items.length > 0 && (
        <>
          <h3 className="mb-2 mt-5 font-semibold">Your recent feedback</h3>
          <ul className="divide-y rounded-lg border">
            {info.items.map((f) => (
              <li key={f.id} className="px-4 py-3">
                <p className="text-xs text-gray-500">{f.category} · {when(f.created_at)}</p>
                <p className="text-sm">{f.message}</p>
              </li>
            ))}
          </ul>
        </>
      )}
    </main>
  );
}

// HOD: everything people have sent.
export function FeedbackInbox({ user }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    api('/api/feedback', { user }).then(setRows).catch((e) => setError(e.message));
  }, [user.id, user.role]);

  if (error) return <p className="p-4 text-sm text-red-600">{error}</p>;
  if (!rows) return <p className="p-4 text-gray-500">Loading…</p>;
  const ROLE = { student: 'Student', teacher: 'Professor', hod: 'HOD' };
  return (
    <div className="p-4">
      <h2 className="mb-2 text-lg font-semibold">App feedback</h2>
      {rows.length === 0 ? (
        <p className="text-gray-500">No feedback yet.</p>
      ) : (
        <ul className="divide-y rounded-lg border">
          {rows.map((f) => (
            <li key={f.id} className="px-4 py-3">
              <p className="text-xs text-gray-500">{ROLE[f.role]} #{f.user_id} · {f.category} · {when(f.created_at)}</p>
              <p className="text-sm">{f.message}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { api, getToken, setToken } from './api.js';
import Welcome from './Welcome.jsx';
import Login from './Login.jsx';
import ChangePassword from './ChangePassword.jsx';
import ClassSessions from './ClassSessions.jsx';
import LiveRoster from './LiveRoster.jsx';
import QRDisplay from './QRDisplay.jsx';
import StudentScanner from './StudentScanner.jsx';
import { Analytics, MyAttendance } from './Analytics.jsx';
import Exams from './Exams.jsx';
import { TeacherEvents, StudentEvents } from './Events.jsx';
import { TeacherLeave, StudentLeave } from './LeaveRequests.jsx';
import Timetable from './Timetable.jsx';
import HodOverview from './HodOverview.jsx';
import OfflineGames from './OfflineGames.jsx';
import KioskScanner from './KioskScanner.jsx';
import Attendance from './Attendance.jsx';
import Feedback, { FeedbackInbox } from './Feedback.jsx';
import { useConnection } from './useConnection.js';

const COURSE_ID = Number(import.meta.env.VITE_COURSE_ID || 1);

const TEACHER_TABS = [
  ['classes', 'Classes'], ['roster', 'Live Roster'], ['qr', 'Class QR'], ['kiosk', 'Scan Students'], ['analytics', 'Analytics'],
  ['timetable', 'Timetable'], ['exams', 'Exams'], ['events', 'Events'], ['leave', 'Leave Requests'],
];
const STUDENT_TABS = [
  ['scan', 'Class Scan'], ['myqr', 'My QR'], ['me', 'My Attendance'], ['leave', 'Leave'], ['timetable', 'Timetable'],
  ['events', 'Events'], ['exams', 'Exams'],
];
const HOD_TABS = [['overview', 'Overview'], ['timetable', 'Timetable'], ['exams', 'Exams'], ['feedback', 'Feedback']];
const OTHER_TABS = [['timetable', 'Timetable'], ['exams', 'Exams']];
const ROLE_LABEL = { hod: 'Head of department', teacher: 'Professor', student: 'Student', other: 'Others' };
const FIRST_TAB = { hod: 'overview', teacher: 'classes', student: 'scan', other: 'timetable' };
const TABS_FOR = { hod: HOD_TABS, teacher: TEACHER_TABS, student: STUDENT_TABS, other: OTHER_TABS };

function NoClass({ go }) {
  return (
    <div className="p-10 text-center text-gray-500">
      <p className="font-medium">No class selected</p>
      <p className="mt-1 text-sm">Start a class, or select one, to continue.</p>
      <button className="mt-3 rounded bg-green-600 px-4 py-2 text-white" onClick={go}>Go to Classes</button>
    </div>
  );
}

function Main({ me, onSignOut }) {
  const [tab, setTab] = useState(FIRST_TAB[me.role]);
  const [session, setSession] = useState(null); // the class the teacher is working with
  const online = useConnection();
  const [showGames, setShowGames] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const user = useMemo(() => ({ key: `${me.role}${me.id}`, label: me.name, role: me.role, id: me.id }), [me]);
  const tabs = TABS_FOR[user.role];

  function go(key) {
    setTab(key);
    setShowGames(false);
    setShowFeedback(false);
    setShowPassword(false);
    setMenuOpen(false);
  }

  // When a teacher signs in, pick up the class that is already open (if any)
  useEffect(() => {
    if (user.role !== 'teacher') return;
    api('/api/sessions')
      .then((rows) => setSession((cur) => cur ?? rows.find((r) => r.is_open) ?? null))
      .catch(() => {});
  }, [user.key]);


  return (
    <div className="mx-auto max-w-3xl">
      <header className="flex items-center justify-between border-b bg-white px-4 py-3">
        <div className="flex items-center gap-3">
          <button className="rounded border px-3 py-1 text-sm" aria-expanded={menuOpen}
                  onClick={() => setMenuOpen((o) => !o)}>
            ☰ Menu
          </button>
          <h1 className="text-lg font-bold">College Attendance</h1>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <span className="hidden max-w-[10rem] truncate sm:inline">{user.label}</span>
          <button className="rounded border px-3 py-1 text-sm" onClick={onSignOut}>Sign out</button>
        </div>
      </header>

      {menuOpen && (
        <div className="border-b bg-white px-4 py-3 shadow-sm">
          <p className="mb-2 text-xs text-gray-500">{user.label} · {ROLE_LABEL[user.role]}</p>
          <div className="grid grid-cols-2 gap-2">
            {tabs.map(([key, label]) => (
              <button key={key} onClick={() => go(key)}
                className={`rounded-lg border px-3 py-2 text-left text-sm ${
                  tab === key && !showGames && !showFeedback && !showPassword ? 'border-green-600 bg-green-50 text-green-800' : 'text-gray-700'
                }`}>
                {label}
              </button>
            ))}
          </div>
          <div className="mt-3 border-t pt-3">
            <div className="flex flex-wrap gap-2">
              <button className="rounded-lg border px-3 py-2 text-sm text-gray-700"
                      onClick={() => { setShowGames(true); setShowFeedback(false); setShowPassword(false); setMenuOpen(false); }}>
                Mind games
              </button>
              <button className="rounded-lg border px-3 py-2 text-sm text-gray-700"
                      onClick={() => { setShowFeedback(true); setShowGames(false); setShowPassword(false); setMenuOpen(false); }}>
                Feedback
              </button>
              <button className="rounded-lg border px-3 py-2 text-sm text-gray-700"
                      onClick={() => { setShowPassword(true); setShowFeedback(false); setShowGames(false); setMenuOpen(false); }}>
                Change password
              </button>
            </div>
          </div>
        </div>
      )}

      {user.role === 'teacher' && session && (
        <div className="bg-green-50 px-4 py-1 text-xs text-green-800">
          Selected class: {session.code} · started{' '}
          {new Date(session.starts_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ·{' '}
          {session.is_open ? 'open' : 'ended'}
        </div>
      )}

      {!online && (
        <div className="flex items-center justify-between gap-2 bg-amber-50 px-4 py-2 text-sm text-amber-800">
          <span>No internet connection. Changes can't be saved right now.</span>
          {!showGames && (
            <button className="rounded border border-amber-300 px-2 py-1" onClick={() => setShowGames(true)}>
              Play a mind game
            </button>
          )}
        </div>
      )}

      <nav className="flex overflow-x-auto border-b bg-white">
        {tabs.map(([key, label]) => (
          <button key={key} onClick={() => go(key)}
            className={`flex-1 whitespace-nowrap px-3 py-3 text-sm font-medium ${
              tab === key ? 'border-b-2 border-green-600 text-green-700' : 'text-gray-500 hover:text-gray-800'
            }`}>
            {label}
          </button>
        ))}
      </nav>

      {showPassword ? (
        <ChangePassword onClose={() => setShowPassword(false)} />
      ) : showFeedback ? (
        <Feedback user={user} onClose={() => setShowFeedback(false)} />
      ) : showGames ? (
        <OfflineGames online={online} onClose={() => setShowGames(false)} />
      ) : (
      <main className="bg-white">
        {user.role === 'hod' ? (
          <>
            {tab === 'overview' && <HodOverview user={user} />}
            {tab === 'timetable' && <Timetable user={user} />}
            {tab === 'exams' && <Exams user={user} />}
            {tab === 'feedback' && <FeedbackInbox user={user} />}
          </>
        ) : user.role === 'teacher' ? (
          <>
            {tab === 'classes' && (
              <ClassSessions user={user} session={session} onSelect={setSession}
                             onStarted={(s) => { setSession(s); setTab('qr'); }} />
            )}
            {tab === 'roster' && (session
              ? <LiveRoster key={session.id} sessionId={session.id} teacherId={user.id} />
              : <NoClass go={() => setTab('classes')} />)}
            {tab === 'qr' && (session
              ? <Attendance key={session.id} session={session} user={user}
                            onOpenScanner={() => setTab('kiosk')}
                            onEnded={(s) => setSession({ ...s, is_open: false })} />
              : <NoClass go={() => setTab('classes')} />)}
            {tab === 'kiosk' && (session
              ? <KioskScanner key={session.id} sessionId={session.id} teacherId={user.id} />
              : <NoClass go={() => setTab('classes')} />)}
            {tab === 'analytics' && <Analytics courseId={COURSE_ID} user={user} />}
            {tab === 'timetable' && <Timetable user={user} />}
            {tab === 'exams' && <Exams user={user} />}
            {tab === 'events' && <TeacherEvents user={user} />}
            {tab === 'leave' && <TeacherLeave user={user} />}
          </>
        ) : user.role === 'other' ? (
          <>
            {tab === 'timetable' && <Timetable user={user} />}
            {tab === 'exams' && <Exams user={user} />}
          </>
        ) : (
          <>
            {tab === 'scan' && <StudentScanner key={user.key} studentId={user.id} />}
            {tab === 'myqr' && (
              <QRDisplay key={user.key} teacherId={user.id} role="student" path="/api/me/qr"
                title="Show this to the class scanner"
                subtitle="Your personal code. It changes every 15 seconds, so a screenshot won't work." />
            )}
            {tab === 'me' && <MyAttendance courseId={COURSE_ID} user={user} />}
            {tab === 'leave' && <StudentLeave key={user.key} user={user} />}
            {tab === 'timetable' && <Timetable user={user} />}
            {tab === 'events' && <StudentEvents key={user.key} user={user} />}
            {tab === 'exams' && <Exams user={user} />}
          </>
        )}
      </main>
      )}
    </div>
  );
}

// The front door: who are you? then sign in, then the app.
export default function App() {
  const [stage, setStage] = useState('loading'); // loading | welcome | login | in
  const [role, setRole] = useState(null);
  const [me, setMe] = useState(null);
  const [notice, setNotice] = useState('');

  // pick up a sign-in made earlier in this tab
  useEffect(() => {
    if (!getToken()) { setStage('welcome'); return; }
    api('/api/auth/me')
      .then((u) => { setMe(u); setStage('in'); })
      .catch(() => { setToken(''); setStage('welcome'); });
  }, []);

  // the sign-in ran out (the server said 401)
  useEffect(() => {
    const expired = () => {
      setMe(null);
      setNotice('Your sign-in ended. Please choose your role and sign in again.');
      setStage('welcome');
    };
    window.addEventListener('auth-expired', expired);
    return () => window.removeEventListener('auth-expired', expired);
  }, []);

  if (stage === 'loading') return <p className="p-10 text-center text-gray-500">Loading…</p>;
  if (stage === 'welcome') {
    return <Welcome notice={notice} onPick={(r) => { setRole(r); setNotice(''); setStage('login'); }} />;
  }
  if (stage === 'login') {
    return (
      <Login role={role} onBack={() => setStage('welcome')}
             onSuccess={(d) => { setToken(d.token); setMe(d.user); setStage('in'); }} />
    );
  }
  return (
    <Main key={`${me.role}-${me.id}`} me={me}
          onSignOut={() => { setToken(''); setMe(null); setRole(null); setStage('welcome'); }} />
  );
}

import { useCallback, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { api, API, socketAuth } from './api.js';

// The live roster of one class: loads it, then keeps it up to date over the socket.
export function useRoster(sessionId, user) {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState('');

  const reload = useCallback(() => api(`/api/sessions/${sessionId}/roster`, { user })
    .then((rows) => { setStudents(rows); setError(''); })
    .catch((e) => setError(e.message)), [sessionId, user.id]);

  useEffect(() => { reload(); }, [reload]);

  useEffect(() => {
    const socket = io(API, { auth: socketAuth() });
    socket.emit('join', sessionId);
    socket.on('attendance', ({ studentId, status, method, excuse_reason, manual_reason }) => {
      setStudents((prev) => prev.map((s) => (s.id === studentId ? {
        ...s, status, method,
        excuse_reason: excuse_reason ?? null,
        manual_reason: manual_reason ?? null,
        excuse_note: status === 'EXCUSED' ? s.excuse_note : null,
        marked_at: status === 'PRESENT' ? new Date().toISOString() : status === 'ABSENT' ? null : s.marked_at,
      } : s)));
    });
    return () => socket.disconnect();
  }, [sessionId]);

  return { students, setStudents, error, setError, reload };
}

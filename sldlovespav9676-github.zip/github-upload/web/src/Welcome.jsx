// The first screen: who are you? The next screen is the sign-in page for that role.
const ROLES = [
  { key: 'student', title: 'Student', blurb: 'Scan the class QR code and see your attendance' },
  { key: 'teacher', title: 'Professor', blurb: 'Start classes and take attendance' },
  { key: 'hod', title: 'HOD', blurb: 'Head of department: overview and timetable' },
  { key: 'other', title: 'Others', blurb: 'Staff and guests: timetable and exam schedule' },
];

export default function Welcome({ onPick, notice }) {
  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <h1 className="text-center text-2xl font-bold">College Attendance</h1>
      <p className="mt-1 text-center text-gray-600">Who are you?</p>
      {notice && <p className="mt-4 rounded bg-amber-50 p-3 text-center text-sm text-amber-800" role="status">{notice}</p>}
      <div className="mt-6 space-y-3">
        {ROLES.map((r) => (
          <button key={r.key} onClick={() => onPick(r.key)}
                  className="w-full rounded-xl border bg-white p-4 text-left shadow-sm hover:border-green-600 hover:bg-green-50">
            <span className="block text-lg font-semibold text-gray-900">{r.title}</span>
            <span className="block text-sm text-gray-600">{r.blurb}</span>
          </button>
        ))}
      </div>
      <p className="mt-6 text-center text-xs text-gray-500">Choose your role first, then sign in.</p>
    </div>
  );
}

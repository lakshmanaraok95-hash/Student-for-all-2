import { useState } from 'react';
import QRDisplay from './QRDisplay.jsx';
import { api } from './api.js';
import { useRoster } from './useRoster.js';
import { rosterTotals } from './rosterTotals.js';

const REASONS = ['Medical', 'Family emergency', 'College event / sports', 'Other'];
const MANUAL_REASONS = ['Technical issue', 'Other'];
const clock = (iso) => (iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '');

const modeClass = (on) =>
  `flex-1 rounded-lg px-2 py-3 text-sm ${on
    ? 'border-2 border-green-600 bg-green-50 font-semibold text-green-700'
    : 'border border-gray-300 bg-white text-gray-800'}`;

const toggleClass = (on, tone) => {
  const tones = {
    green: 'border-2 border-green-600 bg-green-50 font-semibold text-green-700',
    red: 'border-2 border-red-600 bg-red-50 font-semibold text-red-700',
    amber: 'border-2 border-amber-500 bg-amber-50 font-semibold text-amber-800',
  };
  return `rounded-lg px-2 py-2 text-xs ${on ? tones[tone] : 'border border-gray-300 bg-white text-gray-500'}`;
};

const isPresent = (s) => s.status === 'PRESENT' || s.status === 'LATE';

// Teacher's attendance screen. Two ways to take attendance:
//   Scan attendance   - one QR code on screen (or "Open scanner" to scan students' own codes).
//                       Below it the class is split into who is present and who is not yet,
//                       and the teacher can mark a student present by hand (for example when
//                       their phone or the app failed), with the reason recorded.
//   Manual attendance - tap Present / Absent / Excused for every student.
// "Submit attendance" saves everything by ending the class (the QR stops working).
export default function Attendance({ session, user, onOpenScanner, onEnded }) {
  const [mode, setMode] = useState('scan');
  const { students, setStudents, error, setError, reload } = useRoster(session.id, user);
  const [excusing, setExcusing] = useState(null); // { id, reason }
  const [handMark, setHandMark] = useState(null); // { id, reason }
  const [msg, setMsg] = useState(null);
  const t = rosterTotals(students);
  const open = session.is_open;

  const present = students.filter(isPresent);
  const notYet = students.filter((s) => s.status === 'ABSENT');
  const excused = students.filter((s) => s.status === 'EXCUSED');

  async function mark(s, status, reason) {
    if (s.status === status && !reason) return;
    const before = students;
    setStudents((prev) => prev.map((x) => (x.id === s.id ? {
      ...x, status, method: 'MANUAL_OVERRIDE', excuse_reason: null, excuse_note: null,
      manual_reason: status === 'PRESENT' ? reason || null : null,
      marked_at: status === 'PRESENT' ? new Date().toISOString() : null,
    } : x)));
    try {
      await api(`/api/sessions/${session.id}/attendance/${s.id}`,
        { method: 'PUT', user, body: reason ? { status, reason } : { status } });
      setError('');
    } catch {
      setStudents(before);
      setError('Save failed, change reverted');
    }
  }

  async function confirmHandMark() {
    const s = students.find((x) => x.id === handMark.id);
    const reason = handMark.reason;
    setHandMark(null);
    if (s) await mark(s, 'PRESENT', reason);
  }

  async function confirmExcuse() {
    try {
      await api(`/api/sessions/${session.id}/excuse/${excusing.id}`,
        { method: 'PUT', user, body: { reason: excusing.reason, note: '' } });
      setExcusing(null);
      reload();
    } catch (e) {
      setError(e.message);
    }
  }

  async function submit() {
    const ok = window.confirm(
      `Submit attendance for ${session.code}? This ends the class and closes the QR code. Students not marked stay absent.`);
    if (!ok) return;
    try {
      await api(`/api/sessions/${session.id}/end`, { method: 'POST', user });
      setMsg({ ok: true, text: `Attendance submitted: ${t.present} present, ${t.absent} absent${t.excused ? `, ${t.excused} excused` : ''}.` });
      onEnded(session);
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    }
  }

  const presentTag = (s) => (
    <span className="rounded-full bg-green-100 px-2 py-1 text-xs text-green-800">
      {s.method === 'MANUAL_OVERRIDE'
        ? `Present (manual${s.manual_reason ? `: ${s.manual_reason.toLowerCase()}` : ''})`
        : `Present ${clock(s.marked_at)}`}
    </span>
  );

  const groupTitle = (text) => (
    <p className="border-t bg-gray-50 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-gray-500">{text}</p>
  );

  const person = (s) => (
    <div>
      <p className="font-medium">{s.name}</p>
      <p className="text-xs text-gray-500">Roll no. {s.roll_no}</p>
    </div>
  );

  return (
    <div className="p-4">
      <div className="mb-4 flex gap-2">
        <button className={modeClass(mode === 'scan')} aria-pressed={mode === 'scan'} onClick={() => setMode('scan')}>
          Scan attendance
        </button>
        <button className={modeClass(mode === 'manual')} aria-pressed={mode === 'manual'} onClick={() => setMode('manual')}>
          Manual attendance
        </button>
      </div>

      {mode === 'scan' && (
        <>
          {open ? (
            <QRDisplay key={session.id} sessionId={session.id} teacherId={user.id}
                       title={`${session.code}: scan to mark attendance`} />
          ) : (
            <p className="rounded bg-gray-100 p-4 text-center text-gray-600">This class has ended, so there is no QR code.</p>
          )}
          <div className="mt-4 text-center">
            <button disabled={!open} onClick={onOpenScanner}
                    className="w-full rounded-lg border border-green-600 bg-white px-4 py-3 font-semibold text-green-700 disabled:opacity-50">
              Open scanner
            </button>
            <p className="mt-1 text-xs text-gray-500">Or scan each student's personal QR code with this device.</p>
          </div>
        </>
      )}

      <div className="mt-4 overflow-hidden rounded-lg border">
        <div className="flex items-center justify-between p-4">
          <div>
            <p className="font-semibold">{mode === 'manual' ? 'Mark attendance by hand' : 'Class list'}</p>
            <p className="text-sm text-gray-500">
              {mode === 'manual' ? 'Tap Present, Absent or Excused for each student' : `Total in the class: ${t.total} students`}
            </p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-green-700">{t.present} / {t.total}</p>
            <p className="text-xs text-gray-500">present</p>
          </div>
        </div>
        {error && <p className="px-4 pb-2 text-sm text-red-600">{error}</p>}

        {mode === 'scan' ? (
          <>
            {groupTitle(`Present (${present.length})`)}
            {present.length === 0 && <p className="px-4 py-3 text-sm text-gray-500">Nobody has scanned yet.</p>}
            <ul>
              {present.map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-2 border-t px-4 py-3">
                  {person(s)}{presentTag(s)}
                </li>
              ))}
            </ul>

            {groupTitle(`${open ? 'Not present yet' : 'Absent'} (${notYet.length})`)}
            {notYet.length === 0 && <p className="px-4 py-3 text-sm text-gray-500">Everyone is accounted for.</p>}
            <ul>
              {notYet.map((s) => (
                <li key={s.id} className="border-t px-4 py-3">
                  <div className="flex items-center justify-between gap-2">
                    {person(s)}
                    <button disabled={!open}
                            className="rounded-lg border border-green-600 bg-white px-3 py-2 text-sm font-semibold text-green-700 disabled:opacity-40"
                            onClick={() => setHandMark({ id: s.id, reason: MANUAL_REASONS[0] })}>
                      Mark present
                    </button>
                  </div>
                  {handMark && handMark.id === s.id && (
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <select className="rounded border p-2 text-sm" value={handMark.reason} aria-label="why"
                              onChange={(e) => setHandMark({ ...handMark, reason: e.target.value })}>
                        {MANUAL_REASONS.map((r) => <option key={r}>{r}</option>)}
                      </select>
                      <button className="rounded bg-green-600 px-3 py-2 text-sm text-white" onClick={confirmHandMark}>Confirm</button>
                      <button className="rounded border px-3 py-2 text-sm" onClick={() => setHandMark(null)}>Cancel</button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
            {open && notYet.length > 0 && (
              <p className="border-t px-4 py-2 text-xs text-gray-500">
                A student's phone or the app not working? Tap Mark present and choose Technical issue.
              </p>
            )}

            {excused.length > 0 && (
              <>
                {groupTitle(`Excused (${excused.length})`)}
                <ul>
                  {excused.map((s) => (
                    <li key={s.id} className="flex items-center justify-between gap-2 border-t px-4 py-3">
                      {person(s)}
                      <span className="rounded-full bg-amber-100 px-2 py-1 text-xs text-amber-800">Excused: {s.excuse_reason}</span>
                    </li>
                  ))}
                </ul>
              </>
            )}
          </>
        ) : (
          <ul>
            {students.map((s) => (
              <li key={s.id} className="border-t px-4 py-3">
                <div className="flex items-center justify-between gap-2">
                  {person(s)}
                  <div className="flex gap-1">
                    <button disabled={!open} aria-pressed={s.status === 'PRESENT'} className={toggleClass(s.status === 'PRESENT', 'green')}
                            onClick={() => mark(s, 'PRESENT')}>Present</button>
                    <button disabled={!open} aria-pressed={s.status === 'ABSENT'} className={toggleClass(s.status === 'ABSENT', 'red')}
                            onClick={() => mark(s, 'ABSENT')}>Absent</button>
                    <button disabled={!open} aria-pressed={s.status === 'EXCUSED'} className={toggleClass(s.status === 'EXCUSED', 'amber')}
                            onClick={() => setExcusing({ id: s.id, reason: s.excuse_reason || REASONS[0] })}>Excused</button>
                  </div>
                </div>
                {s.status === 'EXCUSED' && s.excuse_reason && (
                  <p className="mt-1 text-xs text-amber-800">Excused: {s.excuse_reason}</p>
                )}
                {excusing && excusing.id === s.id && (
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <select className="rounded border p-2 text-sm" value={excusing.reason}
                            onChange={(e) => setExcusing({ ...excusing, reason: e.target.value })}>
                      {REASONS.map((r) => <option key={r}>{r}</option>)}
                    </select>
                    <button className="rounded bg-green-600 px-3 py-2 text-sm text-white" onClick={confirmExcuse}>Confirm</button>
                    <button className="rounded border px-3 py-2 text-sm" onClick={() => setExcusing(null)}>Cancel</button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
      <p className="mt-2 text-sm text-gray-500">
        Total in the class: {t.total} · Present {t.present} · Absent {t.absent}{t.excused ? ` · Excused ${t.excused}` : ''}
      </p>

      <button disabled={!open} onClick={submit}
              className="mt-4 w-full rounded-lg bg-green-600 px-4 py-3 text-base font-semibold text-white disabled:opacity-50">
        Submit attendance
      </button>
      <p className="mt-2 text-xs text-gray-500">
        Ends the class and closes the QR code. Students who have not scanned stay absent. Students marked by hand show as "Manual".
      </p>
      {msg && <p className={`mt-2 text-sm ${msg.ok ? 'text-green-700' : 'text-red-600'}`}>{msg.text}</p>}
    </div>
  );
}

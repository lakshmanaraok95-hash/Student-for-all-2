// Adds an account, or resets a password. Run it inside backend/.
//
//   NEW_PASSWORD='Something@123' node create-user.js add <role> <login_id> "<Full name>" [actor_id]
//   NEW_PASSWORD='Something@123' node create-user.js reset <role> <login_id>
//
// role: student | teacher | hod | other
// actor_id: students -> the student's id in the students table (required);
//           professors -> the number used in courses.teacher_id (required);
//           hod / other -> optional (the next free number is used).
// The password comes from the NEW_PASSWORD variable so it is not left in the terminal history
// of the command itself; clear your shell history if that matters.
require('dotenv').config();
const { Pool } = require('pg');
const A = require('./auth');

(async () => {
  const [cmd, role, loginId, name, actorArg] = process.argv.slice(2);
  const pw = process.env.NEW_PASSWORD;
  const usage = () => { console.error('Usage: see the comments at the top of create-user.js'); process.exit(1); };
  if (!['add', 'reset'].includes(cmd) || !A.LOGIN_ROLES.includes(role) || !loginId) usage();
  if (cmd === 'add' && !name) usage();
  const err = A.passwordError(pw);
  if (err) { console.error('NEW_PASSWORD problem:', err); process.exit(1); }

  const db = new Pool({ connectionString: process.env.DATABASE_URL });
  try {
    if (cmd === 'reset') {
      const r = await db.query(
        `UPDATE users SET password_hash = $3, failed_attempts = 0, locked_until = NULL
          WHERE role = $1 AND lower(login_id) = lower($2)`, [role, loginId, A.hashPassword(pw)]);
      console.log(r.rowCount ? `Password reset for ${role} ${loginId}.` : 'No such account.');
      return;
    }
    let actorId = actorArg === undefined ? null : Number(actorArg);
    if (['student', 'teacher'].includes(role) && !Number.isInteger(actorId)) {
      console.error(`For a ${role}, give the actor_id as the last argument.`); process.exit(1);
    }
    if (role === 'student') {
      const s = await db.query('SELECT 1 FROM students WHERE id = $1', [actorId]);
      if (!s.rowCount) { console.error('No student with that id. Add the student first.'); process.exit(1); }
    }
    if (actorId === null) {
      const n = await db.query('SELECT COALESCE(MAX(actor_id), 0) + 1 AS next FROM users WHERE role = $1', [role]);
      actorId = n.rows[0].next;
    }
    await db.query(
      'INSERT INTO users (role, login_id, name, password_hash, actor_id) VALUES ($1,$2,$3,$4,$5)',
      [role, loginId.trim(), name.trim(), A.hashPassword(pw), actorId]);
    console.log(`Account created: ${role} ${loginId} (actor_id ${actorId}).`);
  } catch (e) {
    console.error(e.code === '23505' ? 'That ID already has an account for this role.' : `Failed: ${e.message}`);
    process.exit(1);
  } finally {
    await db.end();
  }
})();

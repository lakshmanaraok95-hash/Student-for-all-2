-- College attendance system schema (PostgreSQL)

CREATE TABLE students (
  id          SERIAL PRIMARY KEY,
  roll_no     TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  email       TEXT UNIQUE NOT NULL
);

CREATE TABLE courses (
  id          SERIAL PRIMARY KEY,
  code        TEXT UNIQUE NOT NULL,
  title       TEXT NOT NULL,
  teacher_id  INT NOT NULL
);

CREATE TABLE enrollments (
  student_id  INT REFERENCES students(id) ON DELETE CASCADE,
  course_id   INT REFERENCES courses(id) ON DELETE CASCADE,
  PRIMARY KEY (student_id, course_id)
);

-- One row per class. qr_secret signs the rotating QR tokens.
CREATE TABLE class_sessions (
  id           SERIAL PRIMARY KEY,
  course_id    INT NOT NULL REFERENCES courses(id),
  starts_at    TIMESTAMPTZ NOT NULL,
  ends_at      TIMESTAMPTZ NOT NULL,
  room_lat     DOUBLE PRECISION NOT NULL,
  room_lng     DOUBLE PRECISION NOT NULL,
  radius_m     INT NOT NULL DEFAULT 50,
  qr_secret    TEXT NOT NULL,
  is_open      BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TYPE attendance_status AS ENUM ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED');
CREATE TYPE checkin_method    AS ENUM ('QR', 'MANUAL_OVERRIDE');

CREATE TABLE attendance_records (
  id            SERIAL PRIMARY KEY,
  session_id    INT NOT NULL REFERENCES class_sessions(id) ON DELETE CASCADE,
  student_id    INT NOT NULL REFERENCES students(id),
  status        attendance_status NOT NULL DEFAULT 'ABSENT',
  method        checkin_method,                 -- NULL until marked
  marked_at     TIMESTAMPTZ,
  marked_by     INT,                            -- teacher id for manual overrides
  lat           DOUBLE PRECISION,               -- student's reported position (QR only)
  lng           DOUBLE PRECISION,
  -- Excused absences (health or other valid reasons). Keep notes short and
  -- never store diagnoses: the category is all the system needs.
  excuse_reason TEXT CHECK (excuse_reason IN
                  ('Medical','Family emergency','College event / sports','Other')),
  excuse_note   TEXT,
  excuse_source TEXT,                           -- 'event:<id>' or 'leave:<id>' when set automatically
  -- Why a professor marked a student present by hand (their phone or the app failed)
  manual_reason TEXT CHECK (manual_reason IN ('Technical issue','Other')),
  UNIQUE (session_id, student_id),
  CHECK (status = 'EXCUSED' OR
         (excuse_reason IS NULL AND excuse_note IS NULL AND excuse_source IS NULL))
);

-- Student leave requests. Approving one excuses the student's classes in the date range.
-- Don't ask students for diagnoses: the category is enough.
CREATE TABLE leave_requests (
  id          SERIAL PRIMARY KEY,
  student_id  INT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  from_date   DATE NOT NULL,
  to_date     DATE NOT NULL,
  category    TEXT NOT NULL CHECK (category IN ('Medical','Family emergency','Other')),
  reason      TEXT,
  status      TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  decided_by  INT,
  decided_at  TIMESTAMPTZ,
  CHECK (from_date <= to_date)
);

-- Exam schedule. A room can't be booked twice for the same date and time.
CREATE TABLE exams (
  id          SERIAL PRIMARY KEY,
  course_id   INT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  exam_date   DATE NOT NULL,
  start_time  TIME NOT NULL,
  room        TEXT NOT NULL
);
CREATE UNIQUE INDEX uniq_exam_room_slot ON exams (lower(room), exam_date, start_time);

-- College events (cultural, sports, workshops...). Open to all students.
-- room_lat/room_lng are optional: without them there is no location check.
CREATE TABLE events (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL CHECK (type IN ('Cultural','Sports','Workshop','Other')),
  event_date  DATE NOT NULL,
  room_lat    DOUBLE PRECISION,
  room_lng    DOUBLE PRECISION,
  radius_m    INT NOT NULL DEFAULT 150,
  qr_secret   TEXT NOT NULL,
  created_by  INT
);

CREATE TABLE event_attendance (
  event_id    INT REFERENCES events(id) ON DELETE CASCADE,
  student_id  INT REFERENCES students(id) ON DELETE CASCADE,
  method      checkin_method NOT NULL,
  marked_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (event_id, student_id)
);

-- Students chosen to go to an event on behalf of the college ("on-duty").
-- Applying on-duty excuses their classes on the event date (see server.js).
CREATE TABLE event_participants (
  event_id    INT REFERENCES events(id) ON DELETE CASCADE,
  student_id  INT REFERENCES students(id) ON DELETE CASCADE,
  PRIMARY KEY (event_id, student_id)
);

-- Weekly timetable. day_of_week: 1 = Monday ... 7 = Sunday. The server refuses a period
-- that overlaps another in the same room, or another for the same professor.
CREATE TABLE timetable_slots (
  id          SERIAL PRIMARY KEY,
  course_id   INT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  day_of_week INT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  room        TEXT NOT NULL,
  CHECK (end_time > start_time)
);

-- Accounts. Passwords are never stored, only a salted scrypt hash. actor_id is the id the rest
-- of the app uses for this person: students.id for a student, the id used in courses.teacher_id
-- for a professor, and any unique number for HOD and Others accounts.
CREATE TABLE users (
  id              SERIAL PRIMARY KEY,
  role            TEXT NOT NULL CHECK (role IN ('student','teacher','hod','other')),
  login_id        TEXT NOT NULL,          -- roll number (students) or employee ID / email (staff)
  name            TEXT NOT NULL,
  password_hash   TEXT NOT NULL,
  actor_id        INT NOT NULL,
  failed_attempts INT NOT NULL DEFAULT 0,
  locked_until    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uniq_users_login ON users (role, lower(login_id));

-- Feedback about the app, sent from the menu. Limited to 2 messages per person per 48 hours.
CREATE TABLE feedback (
  id          SERIAL PRIMARY KEY,
  user_id     INT NOT NULL,
  role        TEXT NOT NULL CHECK (role IN ('student','teacher','hod','other')),
  category    TEXT NOT NULL CHECK (category IN ('App problem','Suggestion','Other')),
  message     TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_feedback_user ON feedback(role, user_id, created_at);

CREATE INDEX idx_att_student ON attendance_records(student_id);
CREATE INDEX idx_att_session ON attendance_records(session_id);

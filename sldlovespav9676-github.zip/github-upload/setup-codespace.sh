#!/usr/bin/env bash
# One-time setup inside a GitHub Codespace.
# Usage: bash setup-codespace.sh <ROOM_LAT> <ROOM_LNG> [RADIUS_METERS]
# Example: bash setup-codespace.sh 12.34567 78.12345 100
set -e
if [ -z "$1" ] || [ -z "$2" ]; then
  echo "Usage: bash setup-codespace.sh <ROOM_LAT> <ROOM_LNG> [RADIUS_METERS]"
  exit 1
fi
LAT=$1; LNG=$2; RADIUS=${3:-100}
cd "$(dirname "$0")"

echo "== Installing PostgreSQL =="
sudo apt-get update -y
sudo apt-get install -y postgresql postgresql-contrib
sudo service postgresql start
sleep 3

echo "== Creating database =="
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'postgres';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='attendance'" | grep -q 1 \
  || sudo -u postgres createdb attendance

echo "== Writing backend/.env =="
cat > backend/.env <<ENVEOF
DATABASE_URL=postgres://postgres:postgres@localhost:5432/attendance
ROOM_LAT=$LAT
ROOM_LNG=$LNG
ROOM_RADIUS=$RADIUS
STUDENT_QR_SECRET=$(openssl rand -hex 32 2>/dev/null || date +%s%N | sha256sum | cut -d' ' -f1)
SESSION_SECRET=$(openssl rand -hex 32 2>/dev/null || date +%s%N | sha256sum | cut -d' ' -f1)
ENVEOF
cp -n web/.env.example web/.env || true

echo "== Installing packages and seeding =="
(cd backend && npm install && npm run seed)
(cd web && npm install)

echo ""
echo "Setup done. Start everything with:  bash run-codespace.sh"
echo ""
echo "Sign in with the test accounts (pick your role first):"
echo "  Student CS202601   Student@123"
echo "  Professor EMP001   Teach@123"
echo "  HOD HOD001         Hod@12345"
echo "  Others GUEST01     Guest@123"

#!/usr/bin/env bash
# Starts Postgres, the backend (port 3000) and the web app (port 5173).
# Press Ctrl+C to stop both servers.
cd "$(dirname "$0")"
sudo service postgresql start
(cd backend && npm run dev) &
(cd web && npm run dev) &
wait

# sldlovespav9676: College Attendance System, everything in one folder

This folder holds the whole project and all the information around it.

```
sldlovespav9676/
├── README.md              <- you are here (the map)
├── project/               <- the app itself, ready to upload to GitHub
│   ├── README.md          <- the page GitHub will show
│   ├── backend/           <- Node.js + Express + PostgreSQL server
│   ├── web/               <- React + Tailwind app
│   ├── docs/screens/      <- screen images used in the README
│   ├── setup-codespace.sh <- one-time setup in a Codespace
│   ├── run-codespace.sh   <- starts everything
│   └── .gitignore
├── prompt/
│   └── project-prompt.md  <- the total prompt (short + full) to rebuild the project with an AI
├── demo/
│   └── attendance-demo.html <- clickable practice version (no server needed)
├── design/                <- the design canvas source (11 screens + canvas.json)
└── guides/
    ├── SETUP-GUIDE.md     <- run it, update it, test it on a phone, share it safely
    ├── WHAT-IT-DOES.md    <- every feature and rule in plain words
    ├── OWNERSHIP-NOTE.md  <- fill-in note for handing the project to someone else
    └── sign-in-summary.xlsx <- test accounts, update steps, sign-in rules, limits (spreadsheet)
```

## Where to start

| I want to... | Open |
| --- | --- |
| See how it works without installing anything | `demo/attendance-demo.html` (open it in a browser) |
| Put it on GitHub | `project/` (see `guides/SETUP-GUIDE.md`, section 2) |
| Run the real app | `guides/SETUP-GUIDE.md`, section 1 |
| Rebuild or extend it with an AI | `prompt/project-prompt.md` |
| Understand every feature | `guides/WHAT-IT-DOES.md` |
| Hand the project to someone else | `guides/OWNERSHIP-NOTE.md` |

## Live links (from the chat where this was built)

- Clickable demo: https://claude.ai/artifact/K2AND7tH9PjGcbu1ghSqck
- Design canvas (all screens): https://claude.ai/artifact/XKkqCzWsJQ61rySNf36EVk

The `design/` files are the source of that canvas. They only display inside the canvas viewer, so use the live link to look at them. The demo is a practice copy: it saves nothing and resets when you reload. If you open `demo/attendance-demo.html` offline, the QR picture may not draw because it loads a small library from the internet; everything else works.

## Important to remember

- **Only test accounts exist** (listed in `guides/SETUP-GUIDE.md`). Change them before using the app with real students.
- **Do not put real student data in it yet.** Health-related reasons are sensitive.
- Never share the `.env` file or the `STUDENT_QR_SECRET` value. The real `.env` is not in this folder.
- The images in `project/docs/screens/` are drawings of the screens, not screenshots of the running app.

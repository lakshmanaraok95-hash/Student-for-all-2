# What the system does

## Roles
- **Student:** scans the class QR, sees their own attendance, leave, events, exams, timetable, and can send feedback.
- **Professor:** starts and runs classes, takes attendance, marks excused absences, approves leave, runs exams and events.
- **HOD (head of department):** sees the department overview, sets the timetable, reads app feedback.
- **Others (staff and guests):** see only the timetable and exam schedule, and can send feedback.

**Signing in:** the first screen asks who you are (Student, Professor, HOD or Others), then shows the sign-in page for that role. Passwords are stored only as hashes, a sign-in lasts 12 hours, and 5 wrong tries in a row lock the account for 15 minutes.

## Taking attendance (the main flow)
1. The professor opens **Classes** and starts a class: pick the course, type the **From** and **To** times (hour : minute AM/PM), optionally save the classroom location. Tapping a period from today's timetable fills these in.
2. The app shows **one QR code** that changes every 15 seconds.
3. Every student scans that same code on their own phone. The server checks the code, that the class is open, that the student is enrolled, and that they are near the classroom. Then they are marked present.
4. The professor sees a live class list: **Present** and **Not present yet**, with roll numbers and times.
5. If a student's phone or the app fails, the professor taps **Mark present** and picks **Technical issue** (or Other).
6. **Manual attendance** lets the professor tap Present, Absent or Excused for every student.
7. **Open scanner** lets the professor's tablet scan each student's personal QR code instead.
8. **Submit attendance** ends the class and closes the QR code. Students not marked stay absent.

## Rules worth knowing
- A class is at most 8 hours long; it closes at its To time and cannot be reopened.
- The QR and check-in work only between the From and To times.
- Attendance % = present divided by (classes held minus excused days). Below 75% is flagged.
- Excused reasons: Medical, Family emergency, College event / sports, Other. Notes are short (80 characters) and must not contain diagnoses.

## Around attendance
- **Leave requests:** students ask with dates and a type; the professor approves or rejects. Approving excuses the classes in the date range (never overwriting present).
- **Exams:** schedule with room double-booking prevented.
- **College events:** event QR codes; **Going for the college** plus **Apply on-duty** excuses those students' classes on the event date; **Undo on-duty** reverses only that event's changes.
- **Timetable (HOD):** day, course, room and From and To times. Room clashes and professor clashes are refused; back-to-back periods are fine.
- **HOD overview:** attendance per course, students below 75%, recent classes.
- **Menu:** every section for your role, **Mind games** and **Feedback**.
- **Feedback:** App problem, Suggestion or Other; 5 to 500 characters; **2 messages every 2 days** per person; the HOD reads them.
- **Offline mind games:** Memory Match, Quick Math and Sequence appear when the connection drops.

## Honest limits
- Only test accounts exist (change them before real use); the HOD has no screen yet to create accounts or reset passwords. GPS can be spoofed. Approved leave and on-duty only excuse classes that already exist.

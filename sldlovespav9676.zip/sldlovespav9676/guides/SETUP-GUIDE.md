# Setup guide

Written for working from a tablet with no laptop. The tools and what each is for:

| Tool | What it does here |
| --- | --- |
| **GitHub Codespaces** | Runs the real app (server, database, web app) in your browser. The only place the app really runs. |
| **GitHub** | Stores the code. |
| **vscode.dev** | Only for viewing and editing files. It has no terminal, so it cannot run the app. |
| **The demo page** | A clickable practice copy that needs no setup. |

## 1. Run the app in a Codespace

1. Create a GitHub account, then a **private** repository (tick "Add a README", choose the **Node** .gitignore, license **None**).
2. Put the project on GitHub (section 2 below).
3. Open the repository, tap **Code, then Codespaces, then Create codespace on main**.
4. Find your classroom's latitude and longitude (in Google Maps, press and hold the spot).
5. In the terminal run, with your own numbers:
   ```
   bash setup-codespace.sh 12.34567 78.12345
   ```
   This installs PostgreSQL, creates the database, installs packages and loads test data. It takes a few minutes and ends with "Setup done".
6. Start everything:
   ```
   bash run-codespace.sh
   ```
7. Open the **Ports** tab and open the link for port **5173**. Choose your role, then sign in with a test account (section 1b).

## 1b. Sign in (test accounts)

The first screen asks who you are (Student, Professor, HOD or Others). Pick one, then sign in:

| Role | ID | Password |
| --- | --- | --- |
| Student | CS202601 to CS202605 | Student@123 |
| Professor | EMP001 | Teach@123 |
| HOD | HOD001 | Hod@12345 |
| Others | GUEST01 | Guest@123 |

These are **test accounts**: change or remove them before real use. Everyone can change their own password from the menu. To add an account or reset a password, run this in `backend/`:
```
NEW_PASSWORD='Something@123' node create-user.js add teacher EMP002 "Professor B" 2
NEW_PASSWORD='Something@123' node create-user.js reset student CS202601
```

## 2. Put the project on GitHub (from a tablet)

GitHub's website will not take folders from a tablet, so:
1. Zip the `project/` folder contents (or use `sldlovespav9676-github.zip` if you have it).
2. On the repository page: **Add file, then Upload files**, choose the zip, commit.
3. Open a codespace and run:
   ```
   unzip -o sldlovespav9676-github.zip && rm sldlovespav9676-github.zip
   git add -A && git commit -m "Add attendance system" && git push
   ```
   If `unzip` is not found, use `python3 -m zipfile -e sldlovespav9676-github.zip .` instead.

**Repository description:** College attendance system: one rotating QR code for the whole class, live roster, excused absences, leave, exams, events, timetable and HOD view. Node.js, Express, PostgreSQL, React.
**Topics:** attendance, qr-code, nodejs, react, postgresql, college.

## 3. Update after changes

1. Upload the new zip, run `unzip -o <zip name>`.
2. If you were told the database design changed, run `cd backend && npm run seed` once. **This wipes the test data.**
3. Restart: stop with Ctrl+C, then `bash run-codespace.sh`.

## 4. Try it on a phone

The camera and GPS only work over HTTPS, so use the Codespace link, not a local address.
1. In the **Ports** tab, right-click port 5173, choose **Port Visibility, then Public**.
2. Open the same link on the phone, choose **Student**, sign in (for example CS202601 and Student@123), and allow camera and location.
3. When you are done, set the port back to **Private** and stop the codespace. While it is public, anyone with the link can use the app.

## 5. If something goes wrong

| Problem | What to try |
| --- | --- |
| Camera or location blocked | Use the HTTPS link from the Ports tab and allow the permissions. |
| "No class selected" | Open **Classes**, start a class or select one. |
| QR says the class has not started | The From time is in the future. Edit the time, or wait. |
| "Too far from the classroom" | Your phone is outside the radius of the saved location. Start the class again with "Use my location". |
| Student QR stops working after a restart | `STUDENT_QR_SECRET` is missing. Run `echo "STUDENT_QR_SECRET=$(openssl rand -hex 32)" >> backend/.env` and restart. |
| An error after an update | Run `npm run seed` in `backend/` (wipes test data), then restart. |
| Signed out every time the server restarts | `SESSION_SECRET` is missing. Run `echo "SESSION_SECRET=$(openssl rand -hex 32)" >> backend/.env` and restart. |
| "Too many wrong tries" | Wait 15 minutes, or reset the password with `create-user.js reset`. |
| "Wrong ID or password for this role" | Check you chose the right role on the first screen. |

If an error keeps happening, copy the red error text and ask for help with it.

## 6. Sharing safely

- The **demo page** is safe to share: practice data only.
- The **code and zip** hold no passwords. Never share a real `.env` file or the `STUDENT_QR_SECRET` value.
- A **running Codespace with a Public port** lets anyone reach the sign-in page, and the test passwords are written in this guide. Share briefly, then set it back to Private, and change the test passwords before sharing for real.
- Keep real student names, attendance and health reasons out of any shared copy until the app has real logins and proper hosting.

## 7. What is still missing

A screen for the HOD to create accounts and reset passwords (today it is a command-line tool); a departments table so each HOD sees only their own courses; putting the app online so a whole class can use it; undo for an approved leave; real screenshots in the README.
